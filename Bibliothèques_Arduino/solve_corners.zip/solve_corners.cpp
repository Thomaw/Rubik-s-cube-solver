#include <Arduino.h>             // Permet d'accéder aux types et constantes standard du language Arduino
#include "movements.h"           // Permet d'accéder aux fonctions définies dans la bibliothèques "movements.h"
#include "rotation.h"            // Permet d'accéder aux fonctions définies dans la bibliothèques "rotation.h"
#include "fix_cross.h"           // Permet d'accéder aux fonctions définies dans la bibliothèques "fix_cross.h"
#include "fix_corners.h"         // Permet d'accéder aux fonctions définies dans la bibliothèques "fix_corners.h"
#include "fix_last_corners.h"    // Permet d'accéder aux fonctions définies dans la bibliothèques "fix_last_corners.h"
#include "affichage_cube.h"      // Permet d'accéder aux fonctions définies dans la bibliothèques "affichage_cube.h"
#include "edges.h"               // Permet d'accéder aux fonctions définies dans la bibliothèques "edges.h"
#include "white_cross.h"         // Permet d'accéder aux fonctions définies dans la bibliothèques "white_cross.h"
#include "solve_corners.h"       // Permet d'accéder aux variables définies dans le Header


// Création variable statique 
static int my_former_global;
  
// Fonction qui renvoie la varible statique 
int get_global_3() {
  return my_former_global;
  }

void set_global_3(int solve_stage) {
  if (solve_stage == 4 && my_former_global != 4) {my_former_global = 4;}  // Si la croix a été réalisée, on passe à l'étape suivante
  }

void cube_decide_corners(int solve_stage, char r_face_jaune[9], char face_jaune[9], char r_face_bleue[9], char face_bleue[9], char r_face_blanche[9], char face_blanche[9], char r_face_verte[9], char face_verte[9], char r_face_rouge[9], char face_rouge[9], char r_face_orange[9], char face_orange[9]) {

        Serial.println();
        Serial.println();
        Serial.print("Corners (First Layer): ");
        // La première face est faite correctement
        if (solve_stage == 3 && face_jaune[0] == 'y' && face_bleue[6] == 'b' && face_jaune[2] == 'y' && face_orange[6] == 'o' &&
                face_verte[6] == 'g' && face_jaune[6] == 'y' && face_orange[6] == 'o' && face_jaune[8] == 'y' && face_rouge[6] == 'r'){
                Serial.print("Solved.");
                solve_stage = 4;
                set_global_3(solve_stage);}  // Renvoie la variable solve_stage
                
        else if(solve_stage == 3){
          
                ////////// si njaune sur le dessus
                if (face_bleue[0] == 'y' || face_bleue[2] == 'y' || face_rouge[0] == 'y' || face_rouge[2] == 'y' ||
                    face_verte[0] == 'y' || face_verte[2] == 'y' || face_orange[0] == 'y' || face_orange[2] == 'y' ||
                    face_blanche[0] == 'y' || face_blanche[2] == 'y' || face_blanche[6] == 'y' || face_blanche[8] == 'y'){
                      
                        ////////// Faire tous les cas possibles pour le coin (4×3) :
                        //////// 3 cas pour les côtés bleu/orange
                        if (face_bleue[2] == 'y' && face_blanche[8] == 'b' && face_orange[0] == 'o'){
                                fix_corners_instance_2(r_face_jaune, face_jaune, r_face_bleue, face_bleue, r_face_blanche, face_blanche, r_face_verte, face_verte, r_face_rouge, face_rouge, r_face_orange, face_orange);}
                                
                        else if (face_bleue[2] == 'o' && face_blanche[8] == 'y' && face_orange[0] == 'b'){
                                fix_corners_instance_2(r_face_jaune, face_jaune, r_face_bleue, face_bleue, r_face_blanche, face_blanche, r_face_verte, face_verte, r_face_rouge, face_rouge, r_face_orange, face_orange);
                                fix_corners_instance_2(r_face_jaune, face_jaune, r_face_bleue, face_bleue, r_face_blanche, face_blanche, r_face_verte, face_verte, r_face_rouge, face_rouge, r_face_orange, face_orange);
                                back(r_face_bleue,face_bleue, r_face_orange, face_orange,  r_face_verte, face_verte, r_face_rouge, face_rouge, r_face_blanche, face_blanche);
                                fix_corners_instance_2(r_face_jaune, face_jaune, r_face_bleue, face_bleue, r_face_blanche, face_blanche, r_face_verte, face_verte, r_face_rouge, face_rouge, r_face_orange, face_orange);}
                                
                        else if (face_bleue[2] == 'b' && face_blanche[8] == 'o' && face_orange[0] == 'y'){
                                flip_cube( 'f',  r_face_jaune,  face_jaune,  r_face_bleue, face_bleue,  r_face_blanche,  face_blanche,  r_face_verte,  face_verte,  r_face_rouge, face_rouge,  r_face_orange,  face_orange);
                                fix_corners_instance_1(r_face_jaune, face_jaune, r_face_bleue, face_bleue, r_face_blanche, face_blanche, r_face_verte, face_verte, r_face_rouge, face_rouge, r_face_orange, face_orange);
                                flip_cube( 'F',  r_face_jaune,  face_jaune,  r_face_bleue, face_bleue,  r_face_blanche,  face_blanche,  r_face_verte,  face_verte,  r_face_rouge, face_rouge,  r_face_orange,  face_orange);}
                                
                        //////// 3 cas pour les côtés orange/vert
                        else if (face_orange[2] == 'y' && face_blanche[2] == 'o' && face_verte[0] == 'g'){
                                flip_cube( 'f',  r_face_jaune,  face_jaune,  r_face_bleue, face_bleue,  r_face_blanche,  face_blanche,  r_face_verte,  face_verte,  r_face_rouge, face_rouge,  r_face_orange,  face_orange);
                                fix_corners_instance_2(r_face_jaune, face_jaune, r_face_bleue, face_bleue, r_face_blanche, face_blanche, r_face_verte, face_verte, r_face_rouge, face_rouge, r_face_orange, face_orange);
                                flip_cube( 'F',  r_face_jaune,  face_jaune,  r_face_bleue, face_bleue,  r_face_blanche,  face_blanche,  r_face_verte,  face_verte,  r_face_rouge, face_rouge,  r_face_orange,  face_orange);}
                        
                        else if (face_orange[2] == 'g' && face_blanche[2] == 'y' && face_verte[0] == 'o'){
                                flip_cube( 'f',  r_face_jaune,  face_jaune,  r_face_bleue, face_bleue,  r_face_blanche,  face_blanche,  r_face_verte,  face_verte,  r_face_rouge, face_rouge,  r_face_orange,  face_orange);
                                fix_corners_instance_2(r_face_jaune, face_jaune, r_face_bleue, face_bleue, r_face_blanche, face_blanche, r_face_verte, face_verte, r_face_rouge, face_rouge, r_face_orange, face_orange);
                                fix_corners_instance_2(r_face_jaune, face_jaune, r_face_bleue, face_bleue, r_face_blanche, face_blanche, r_face_verte, face_verte, r_face_rouge, face_rouge, r_face_orange, face_orange);
                                back(r_face_bleue,face_bleue, r_face_orange, face_orange,  r_face_verte, face_verte, r_face_rouge, face_rouge, r_face_blanche, face_blanche);
                                fix_corners_instance_2(r_face_jaune, face_jaune, r_face_bleue, face_bleue, r_face_blanche, face_blanche, r_face_verte, face_verte, r_face_rouge, face_rouge, r_face_orange, face_orange);
                                flip_cube( 'F',  r_face_jaune,  face_jaune,  r_face_bleue, face_bleue,  r_face_blanche,  face_blanche,  r_face_verte,  face_verte,  r_face_rouge, face_rouge,  r_face_orange,  face_orange);}
                                
                        else if (face_orange[2] == 'o' && face_blanche[2] == 'g' && face_verte[0] == 'y'){
                                flip_cube( 'F',  r_face_jaune,  face_jaune,  r_face_bleue, face_bleue,  r_face_blanche,  face_blanche,  r_face_verte,  face_verte,  r_face_rouge, face_rouge,  r_face_orange,  face_orange);
                                flip_cube( 'F',  r_face_jaune,  face_jaune,  r_face_bleue, face_bleue,  r_face_blanche,  face_blanche,  r_face_verte,  face_verte,  r_face_rouge, face_rouge,  r_face_orange,  face_orange);
                                fix_corners_instance_1(r_face_jaune, face_jaune, r_face_bleue, face_bleue, r_face_blanche, face_blanche, r_face_verte, face_verte, r_face_rouge, face_rouge, r_face_orange, face_orange);
                                flip_cube( 'f',  r_face_jaune,  face_jaune,  r_face_bleue, face_bleue,  r_face_blanche,  face_blanche,  r_face_verte,  face_verte,  r_face_rouge, face_rouge,  r_face_orange,  face_orange);
                                flip_cube( 'f',  r_face_jaune,  face_jaune,  r_face_bleue, face_bleue,  r_face_blanche,  face_blanche,  r_face_verte,  face_verte,  r_face_rouge, face_rouge,  r_face_orange,  face_orange);}
                                
                        //////// 3 cas pour les côtés vert et rouge
                        else if (face_verte[2] == 'y' && face_blanche[0] == 'g' && face_rouge[0] == 'r'){
                                flip_cube( 'F',  r_face_jaune,  face_jaune,  r_face_bleue, face_bleue,  r_face_blanche,  face_blanche,  r_face_verte,  face_verte,  r_face_rouge, face_rouge,  r_face_orange,  face_orange);
                                flip_cube( 'F',  r_face_jaune,  face_jaune,  r_face_bleue, face_bleue,  r_face_blanche,  face_blanche,  r_face_verte,  face_verte,  r_face_rouge, face_rouge,  r_face_orange,  face_orange);
                                fix_corners_instance_2(r_face_jaune, face_jaune, r_face_bleue, face_bleue, r_face_blanche, face_blanche, r_face_verte, face_verte, r_face_rouge, face_rouge, r_face_orange, face_orange);
                                flip_cube( 'f',  r_face_jaune,  face_jaune,  r_face_bleue, face_bleue,  r_face_blanche,  face_blanche,  r_face_verte,  face_verte,  r_face_rouge, face_rouge,  r_face_orange,  face_orange);
                                flip_cube( 'f',  r_face_jaune,  face_jaune,  r_face_bleue, face_bleue,  r_face_blanche,  face_blanche,  r_face_verte,  face_verte,  r_face_rouge, face_rouge,  r_face_orange,  face_orange);}
                                
                        else if (face_verte[2] == 'r' && face_blanche[0] == 'y' && face_rouge[0] == 'g'){
                                flip_cube( 'F',  r_face_jaune,  face_jaune,  r_face_bleue, face_bleue,  r_face_blanche,  face_blanche,  r_face_verte,  face_verte,  r_face_rouge, face_rouge,  r_face_orange,  face_orange);
                                flip_cube( 'F',  r_face_jaune,  face_jaune,  r_face_bleue, face_bleue,  r_face_blanche,  face_blanche,  r_face_verte,  face_verte,  r_face_rouge, face_rouge,  r_face_orange,  face_orange);
                                fix_corners_instance_2(r_face_jaune, face_jaune, r_face_bleue, face_bleue, r_face_blanche, face_blanche, r_face_verte, face_verte, r_face_rouge, face_rouge, r_face_orange, face_orange);
                                fix_corners_instance_2(r_face_jaune, face_jaune, r_face_bleue, face_bleue, r_face_blanche, face_blanche, r_face_verte, face_verte, r_face_rouge, face_rouge, r_face_orange, face_orange);
                                back(r_face_bleue,face_bleue, r_face_orange, face_orange,  r_face_verte, face_verte, r_face_rouge, face_rouge, r_face_blanche, face_blanche);
                                fix_corners_instance_2(r_face_jaune, face_jaune, r_face_bleue, face_bleue, r_face_blanche, face_blanche, r_face_verte, face_verte, r_face_rouge, face_rouge, r_face_orange, face_orange);
                                flip_cube( 'f',  r_face_jaune,  face_jaune,  r_face_bleue, face_bleue,  r_face_blanche,  face_blanche,  r_face_verte,  face_verte,  r_face_rouge, face_rouge,  r_face_orange,  face_orange);
                                flip_cube( 'f',  r_face_jaune,  face_jaune,  r_face_bleue, face_bleue,  r_face_blanche,  face_blanche,  r_face_verte,  face_verte,  r_face_rouge, face_rouge,  r_face_orange,  face_orange);}
                                
                        else if (face_verte[2] == 'g' && face_blanche[0] == 'r' && face_rouge[0] == 'y'){
                                flip_cube( 'F',  r_face_jaune,  face_jaune,  r_face_bleue, face_bleue,  r_face_blanche,  face_blanche,  r_face_verte,  face_verte,  r_face_rouge, face_rouge,  r_face_orange,  face_orange);
                                fix_corners_instance_1(r_face_jaune, face_jaune, r_face_bleue, face_bleue, r_face_blanche, face_blanche, r_face_verte, face_verte, r_face_rouge, face_rouge, r_face_orange, face_orange);
                                flip_cube( 'f',  r_face_jaune,  face_jaune,  r_face_bleue, face_bleue,  r_face_blanche,  face_blanche,  r_face_verte,  face_verte,  r_face_rouge, face_rouge,  r_face_orange,  face_orange);}
                                
                        //////// 3 cas pour les côtés rouge/bleu
                        else if (face_rouge[2] == 'y' && face_blanche[6] == 'r' && face_bleue[0] == 'b'){
                                flip_cube( 'F',  r_face_jaune,  face_jaune,  r_face_bleue, face_bleue,  r_face_blanche,  face_blanche,  r_face_verte,  face_verte,  r_face_rouge, face_rouge,  r_face_orange,  face_orange);
                                fix_corners_instance_2(r_face_jaune, face_jaune, r_face_bleue, face_bleue, r_face_blanche, face_blanche, r_face_verte, face_verte, r_face_rouge, face_rouge, r_face_orange, face_orange);
                                flip_cube( 'f',  r_face_jaune,  face_jaune,  r_face_bleue, face_bleue,  r_face_blanche,  face_blanche,  r_face_verte,  face_verte,  r_face_rouge, face_rouge,  r_face_orange,  face_orange);}
                                
                        else if (face_rouge[2] == 'b' && face_blanche[6] == 'y' && face_bleue[0] == 'r'){
                                fix_corners_instance_1(r_face_jaune, face_jaune, r_face_bleue, face_bleue, r_face_blanche, face_blanche, r_face_verte, face_verte, r_face_rouge, face_rouge, r_face_orange, face_orange);
                                fix_corners_instance_1(r_face_jaune, face_jaune, r_face_bleue, face_bleue, r_face_blanche, face_blanche, r_face_verte, face_verte, r_face_rouge, face_rouge, r_face_orange, face_orange);
                                back_inverted(r_face_bleue, face_bleue, r_face_orange, face_orange, r_face_verte, face_verte, r_face_rouge, face_rouge, r_face_blanche, face_blanche);
                                fix_corners_instance_1(r_face_jaune, face_jaune, r_face_bleue, face_bleue, r_face_blanche, face_blanche, r_face_verte, face_verte, r_face_rouge, face_rouge, r_face_orange, face_orange);}
                                
                        else if (face_rouge[2] == 'r' && face_blanche[6] == 'b' && face_bleue[0] == 'y'){
                                fix_corners_instance_1(r_face_jaune, face_jaune, r_face_bleue, face_bleue, r_face_blanche, face_blanche, r_face_verte, face_verte, r_face_rouge, face_rouge, r_face_orange, face_orange);}
                                
                        else{back(r_face_bleue,face_bleue, r_face_orange, face_orange,  r_face_verte, face_verte, r_face_rouge, face_rouge, r_face_blanche, face_blanche);}  // move yellow on top of correct position
                }
                
                ////////// s'il n'y a pas de jaunes sur le dessus et que la première couche n'est pas déjà résolue
                else if (face_jaune[0] != 'y' || face_rouge[8] != 'r' || face_bleue[6] != 'b' ||
                                 face_jaune[2] != 'y' || face_orange[6] != 'o' || face_bleue[8] != 'b' ||
                                 face_jaune[8] != 'y' || face_orange[8] != 'o' || face_verte[6] != 'g' ||
                                 face_jaune[6] != 'y' || face_rouge[6] != 'r' || face_bleue[8] != 'g'){
                                  
                        //////////// Remontez tous les coins jaunes :
                        // Coin bleu et rouge
                        if (face_jaune[0] != 'y' || face_rouge[8] != 'r' || face_bleue[6] != 'b'){
                                fix_corners_instance_3(r_face_jaune, face_jaune, r_face_bleue, face_bleue, r_face_blanche, face_blanche, r_face_verte, face_verte, r_face_rouge, face_rouge, r_face_orange, face_orange);}
                                
                        // coin bleu et orange
                        else if (face_jaune[2] != 'y' || face_orange[6] != 'o' || face_bleue[8] != 'b'){
                                flip_cube( 'f',  r_face_jaune,  face_jaune,  r_face_bleue, face_bleue,  r_face_blanche,  face_blanche,  r_face_verte,  face_verte,  r_face_rouge, face_rouge,  r_face_orange,  face_orange);
                                fix_corners_instance_3(r_face_jaune, face_jaune, r_face_bleue, face_bleue, r_face_blanche, face_blanche, r_face_verte, face_verte, r_face_rouge, face_rouge, r_face_orange, face_orange);
                                flip_cube( 'F',  r_face_jaune,  face_jaune,  r_face_bleue, face_bleue,  r_face_blanche,  face_blanche,  r_face_verte,  face_verte,  r_face_rouge, face_rouge,  r_face_orange,  face_orange);}
                                
                        // Coin orange et vert
                        else if (face_jaune[8] != 'y' || face_orange[8] != 'o' || face_verte[6] != 'g'){
                                flip_cube( 'f',  r_face_jaune,  face_jaune,  r_face_bleue, face_bleue,  r_face_blanche,  face_blanche,  r_face_verte,  face_verte,  r_face_rouge, face_rouge,  r_face_orange,  face_orange);
                                flip_cube( 'f',  r_face_jaune,  face_jaune,  r_face_bleue, face_bleue,  r_face_blanche,  face_blanche,  r_face_verte,  face_verte,  r_face_rouge, face_rouge,  r_face_orange,  face_orange);
                                fix_corners_instance_3(r_face_jaune, face_jaune, r_face_bleue, face_bleue, r_face_blanche, face_blanche, r_face_verte, face_verte, r_face_rouge, face_rouge, r_face_orange, face_orange);
                                flip_cube( 'F',  r_face_jaune,  face_jaune,  r_face_bleue, face_bleue,  r_face_blanche,  face_blanche,  r_face_verte,  face_verte,  r_face_rouge, face_rouge,  r_face_orange,  face_orange);
                                flip_cube( 'F',  r_face_jaune,  face_jaune,  r_face_bleue, face_bleue,  r_face_blanche,  face_blanche,  r_face_verte,  face_verte,  r_face_rouge, face_rouge,  r_face_orange,  face_orange);}
                                
                        // Coin vert et rouge
                        else if (face_jaune[6] != 'y' || face_rouge[6] != 'r' || face_bleue[8] != 'g'){
                                flip_cube( 'F',  r_face_jaune,  face_jaune,  r_face_bleue, face_bleue,  r_face_blanche,  face_blanche,  r_face_verte,  face_verte,  r_face_rouge, face_rouge,  r_face_orange,  face_orange);
                                fix_corners_instance_3(r_face_jaune, face_jaune, r_face_bleue, face_bleue, r_face_blanche, face_blanche, r_face_verte, face_verte, r_face_rouge, face_rouge, r_face_orange, face_orange);
                                flip_cube( 'f',  r_face_jaune,  face_jaune,  r_face_bleue, face_bleue,  r_face_blanche,  face_blanche,  r_face_verte,  face_verte,  r_face_rouge, face_rouge,  r_face_orange,  face_orange);}
                }
                else{Serial.println("First Layer not Solved.");}  // Erreur dans le cube
        }      
}




  
