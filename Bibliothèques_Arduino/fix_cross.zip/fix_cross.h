/*
  fix_cross.h - Bibliothèque permettant de résoudre
  des problèmes liés à l'orientation de la croix centrale 
  du cube

  Créé par Dubouchet Thomas, 29 Décembre 2020
  Tout droit réservé
*/

/*
  Les procédures de cette bibliothèque seront en anglais car la terminologie utilisée
  est la terminologie officielle 

  
  Procédures de cette bibliothèque:
  
  void fix_cross_instance_1
    - Permets de réaliser la suite de mouvements suivante:
    R, R, B, U, U, B', R, R

  fix_cross_instance_2
    - Permets de réaliser la suite de mouvements suivante:
    U, U, B, B, D, D, B, B, U, U

 */


// Les deux lignes ci-dessous permettent d'éviter les problèmes si quelqu'un inclut la bibliothèque deux fois.
#ifndef fix_cross_h
#define fix_cross_h

// ----------------------------------------------------------- //
// --------- Liste des procédures de la bibliothèque --------- //
// ----------------------------------------------------------- //

void fix_cross_instance_1(char r_jaune[9], char jaune[9], char r_bleue[9], char bleue[9], char r_blanche[9], char blanche[9], char r_verte[9], char verte[9], char r_rouge[9], char rouge[9], char r_orange[9], char orange[9]);
void fix_cross_instance_2(char r_jaune[9], char jaune[9], char r_bleue[9], char bleue[9], char r_blanche[9], char blanche[9], char r_verte[9], char verte[9], char r_rouge[9], char rouge[9], char r_orange[9], char orange[9]);

#endif  // Fin de la création de la bibliothèque
