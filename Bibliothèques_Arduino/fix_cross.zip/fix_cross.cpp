#include <Arduino.h>    // Permets d'accéder aux types et constantes standard du language Arduino
#include "movements.h"  // Permets d'accéder aux fonctions définies dans la bibliothèques "movements.h" 
#include "fix_cross.h"  // Permets d'accéder aux variables définies dans le Header

// Orientation de la croix 

// Réalise les mouvements suivants: R, R, B, U, U, B', R, R
void fix_cross_instance_1(char r_face_jaune[9], char face_jaune[9], char r_face_bleue[9], char face_bleue[9], char r_face_blanche[9], char face_blanche[9], char r_face_verte[9], char face_verte[9], char r_face_rouge[9], char face_rouge[9], char r_face_orange[9], char face_orange[9]){ // bad pieces up and right
        Serial.println();
        Serial.print("  Fix Cross Instance 1: ");

        // cube simulation
        right(r_face_jaune,face_jaune,r_face_bleue,face_bleue,r_face_blanche,face_blanche,r_face_verte, face_verte,r_face_orange,face_orange);
        right(r_face_jaune,face_jaune,r_face_bleue,face_bleue,r_face_blanche,face_blanche,r_face_verte, face_verte,r_face_orange,face_orange);
        back(r_face_bleue,face_bleue, r_face_orange, face_orange,  r_face_verte, face_verte, r_face_rouge, face_rouge, r_face_blanche, face_blanche);
        up(r_face_jaune, face_jaune, r_face_blanche, face_blanche, r_face_bleue, face_bleue, r_face_rouge, face_rouge, r_face_orange, face_orange);
        up(r_face_jaune, face_jaune, r_face_blanche, face_blanche, r_face_bleue, face_bleue, r_face_rouge, face_rouge, r_face_orange, face_orange);
        back_inverted(r_face_bleue, face_bleue, r_face_orange, face_orange, r_face_verte, face_verte, r_face_rouge, face_rouge, r_face_blanche, face_blanche);
        right(r_face_jaune,face_jaune,r_face_bleue,face_bleue,r_face_blanche,face_blanche,r_face_verte, face_verte,r_face_orange,face_orange);
        right(r_face_jaune,face_jaune,r_face_bleue,face_bleue,r_face_blanche,face_blanche,r_face_verte, face_verte,r_face_orange,face_orange);}


// Réalise les mouvements suivants: U, U, B, B, D, D, B, B, U, U
void fix_cross_instance_2(char r_face_jaune[9], char face_jaune[9], char r_face_bleue[9], char face_bleue[9], char r_face_blanche[9], char face_blanche[9], char r_face_verte[9], char face_verte[9], char r_face_rouge[9], char face_rouge[9], char r_face_orange[9], char face_orange[9]){ // bad pieces up and down
        Serial.println();
        Serial.print("  Fix Cross Instance 2: ");

        // cube simulation
        up(r_face_jaune, face_jaune, r_face_blanche, face_blanche, r_face_bleue, face_bleue, r_face_rouge, face_rouge, r_face_orange, face_orange);
        up(r_face_jaune, face_jaune, r_face_blanche, face_blanche, r_face_bleue, face_bleue, r_face_rouge, face_rouge, r_face_orange, face_orange);
        back(r_face_bleue,face_bleue, r_face_orange, face_orange,  r_face_verte, face_verte, r_face_rouge, face_rouge, r_face_blanche, face_blanche);
        back(r_face_bleue,face_bleue, r_face_orange, face_orange,  r_face_verte, face_verte, r_face_rouge, face_rouge, r_face_blanche, face_blanche);
        down( r_face_jaune, face_jaune, r_face_blanche, face_blanche,  r_face_verte, face_verte,  r_face_rouge, face_rouge, r_face_orange, face_orange);
        down( r_face_jaune, face_jaune, r_face_blanche, face_blanche,  r_face_verte, face_verte,  r_face_rouge, face_rouge, r_face_orange, face_orange);
        back(r_face_bleue,face_bleue, r_face_orange, face_orange,  r_face_verte, face_verte, r_face_rouge, face_rouge, r_face_blanche, face_blanche);
        back(r_face_bleue,face_bleue, r_face_orange, face_orange,  r_face_verte, face_verte, r_face_rouge, face_rouge, r_face_blanche, face_blanche);
        up(r_face_jaune, face_jaune, r_face_blanche, face_blanche, r_face_bleue, face_bleue, r_face_rouge, face_rouge, r_face_orange, face_orange);
        up(r_face_jaune, face_jaune, r_face_blanche, face_blanche, r_face_bleue, face_bleue, r_face_rouge, face_rouge, r_face_orange, face_orange);}


        
