# include <Arduino.h>        // Permets d'accéder aux types et constantes standard du language Arduino
# include "affichage_cube.h" // Permets d'accéder aux variables définit dans le Header


// Affiche dans le moniteur série une face du cube
void print_cube(char cube_side[9]){                   // Initialisation avec le nom de la face utilisée
  for (int i = 0; i < 1; i++){Serial.println('\r');}  // Retour du chariot
  
  Serial.print("Face: ");                             // Affichage de "Face"
  Serial.println(cube_side[4]);                       // Affichage du nom de la face
  
  for(int i = 0; i < 9; i = i+3){                     // Pour chacun des 9 cubes de la face 
    Serial.print("|");                                // Affichage de "|" pour une meilleure mise en forme
    Serial.print(cube_side[i]);                       // Affiche le cube n°i
    Serial.print("|");
    Serial.print(cube_side[i+1]);                     // Affiche le cube n°i+1
    Serial.print("|");
    Serial.print(cube_side[i+2]);                     // Affiche le cube n°i+2
    Serial.println("|");}
}

// Affichage de toutes les faces
void print_whole_cube(char cube_side1[9],char cube_side2[9],char cube_side3[9],char cube_side4[9],char cube_side5[9],char cube_side6[9]){ // Initialisation avec les 6 faces du cube
  print_cube(cube_side1);     // Affichage de la première face via la procédure précédente
  print_cube(cube_side2);     // Affichage de la deuxième face via la procédure précédente
  print_cube(cube_side3);     // Affichage de la troisième face via la procédure précédente
  print_cube(cube_side4);     // Affichage de la quatrième face via la procédure précédente
  print_cube(cube_side5);     // Affichage de la cinquième face via la procédure précédente
  print_cube(cube_side6);}    // Affichage de la sixième face via la procédure précédente
