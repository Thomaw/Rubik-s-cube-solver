/*
  affichage_cube.h - Bibliothèque permettant d'afficher 
  de manière élégante le Rubik's cube sur le moniteur série

  Créé par Dubouchet Thomas, 28 Novembre 2020
  Tout droit réservé
*/

/*
  Procédures de cette bibliothèque:
  
  void affichage_face(face) 
     - Permets d'afficher une face du Rubik's cube sur le moniteur série 
     
  void affichage_six_faces(face1, face2, face3, face4, face5, face6) 
     - Pemets d'afficher toutes les faces du cube sur le moniteur série
 */


// Les deux lignes ci-dessous permettent d'éviter les problèmes si quelqu'un inclut la bibliothèque deux fois.
#ifndef affichage_cube_h    
#define affichage_cube_h

// ----------------------------------------------------------- //
// --------- Liste des procédures de la bibliothèque --------- //
// ----------------------------------------------------------- //

void print_cube(char cube_side[9]);
void print_whole_cube(char cube_side1[9],char cube_side2[9],char cube_side3[9],char cube_side4[9],char cube_side5[9],char cube_side6[9]);

#endif // Fin de la création de la bibliothèque