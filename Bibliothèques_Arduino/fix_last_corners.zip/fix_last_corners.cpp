#include <Arduino.h>           // Permets d'accéder aux types et constantes standard du language Arduino
#include "movements.h"         // Permets d'accéder aux fonctions définies dans la bibliothèques "movements.h" 
#include "fix_last_corners.h"  // Permets d'accéder aux variables définies dans le Header

// Orientation des derniers angles

// Réalise les mouvements suivants: R', U, R', D, D, R, U', R', D, D, R, R
void green_on_right(char r_face_jaune[9], char face_jaune[9], char r_face_bleue[9], char face_bleue[9], char r_face_blanche[9], char face_blanche[9], char r_face_verte[9], char face_verte[9], char r_face_rouge[9], char face_rouge[9], char r_face_orange[9], char face_orange[9]){
        Serial.println();
        Serial.print("  Green On Right: ");
        // cube simulation
        right_inverted( r_face_jaune, face_jaune, r_face_bleue,face_bleue, r_face_blanche, face_blanche, r_face_verte, face_verte, r_face_orange,face_orange);
        up(r_face_jaune, face_jaune, r_face_blanche, face_blanche, r_face_bleue, face_bleue, r_face_rouge, face_rouge, r_face_orange, face_orange);
        right_inverted( r_face_jaune, face_jaune, r_face_bleue,face_bleue, r_face_blanche, face_blanche, r_face_verte, face_verte, r_face_orange,face_orange);
        down( r_face_jaune, face_jaune, r_face_blanche, face_blanche,  r_face_verte, face_verte,  r_face_rouge, face_rouge, r_face_orange, face_orange);
        down( r_face_jaune, face_jaune, r_face_blanche, face_blanche,  r_face_verte, face_verte,  r_face_rouge, face_rouge, r_face_orange, face_orange);
        right(r_face_jaune,face_jaune,r_face_bleue,face_bleue,r_face_blanche,face_blanche,r_face_verte, face_verte,r_face_orange,face_orange);
        up_inverted( r_face_jaune,face_jaune, r_face_blanche, face_blanche, r_face_bleue, face_bleue, r_face_rouge,face_rouge, r_face_orange, face_orange);
        right_inverted( r_face_jaune, face_jaune, r_face_bleue,face_bleue, r_face_blanche, face_blanche, r_face_verte, face_verte, r_face_orange,face_orange);
        down( r_face_jaune, face_jaune, r_face_blanche, face_blanche,  r_face_verte, face_verte,  r_face_rouge, face_rouge, r_face_orange, face_orange);
        down( r_face_jaune, face_jaune, r_face_blanche, face_blanche,  r_face_verte, face_verte,  r_face_rouge, face_rouge, r_face_orange, face_orange);
        right(r_face_jaune,face_jaune,r_face_bleue,face_bleue,r_face_blanche,face_blanche,r_face_verte, face_verte,r_face_orange,face_orange);
        right(r_face_jaune,face_jaune,r_face_bleue,face_bleue,r_face_blanche,face_blanche,r_face_verte, face_verte,r_face_orange,face_orange);}


// Réalise les mouvements suivants: L, U', L, D', D', L', U, L, D', D', L', L'
void green_on_left(char r_face_jaune[9], char face_jaune[9], char r_face_bleue[9], char face_bleue[9], char r_face_blanche[9], char face_blanche[9], char r_face_verte[9], char face_verte[9], char r_face_rouge[9], char face_rouge[9], char r_face_orange[9], char face_orange[9]){
        Serial.println();
        Serial.print("  Green On Left: ");
        // cube simulation
        left(r_face_jaune, face_jaune, r_face_bleue, face_bleue, r_face_blanche, face_blanche, r_face_verte, face_verte, r_face_rouge, face_rouge);
        up_inverted( r_face_jaune,face_jaune, r_face_blanche, face_blanche, r_face_bleue, face_bleue, r_face_rouge,face_rouge, r_face_orange, face_orange);
        left(r_face_jaune, face_jaune, r_face_bleue, face_bleue, r_face_blanche, face_blanche, r_face_verte, face_verte, r_face_rouge, face_rouge);
        down_inverted( r_face_jaune,face_jaune,  r_face_blanche,  face_blanche,  r_face_verte, face_verte, r_face_rouge,face_rouge, r_face_orange,face_orange);
        down_inverted( r_face_jaune,face_jaune,  r_face_blanche,  face_blanche,  r_face_verte, face_verte, r_face_rouge,face_rouge, r_face_orange,face_orange);
        left_inverted(r_face_jaune, face_jaune, r_face_bleue, face_bleue, r_face_blanche, face_blanche, r_face_verte, face_verte, r_face_rouge, face_rouge);
        up(r_face_jaune, face_jaune, r_face_blanche, face_blanche, r_face_bleue, face_bleue, r_face_rouge, face_rouge, r_face_orange, face_orange);
        left(r_face_jaune, face_jaune, r_face_bleue, face_bleue, r_face_blanche, face_blanche, r_face_verte, face_verte, r_face_rouge, face_rouge);
        down_inverted( r_face_jaune,face_jaune,  r_face_blanche,  face_blanche,  r_face_verte, face_verte, r_face_rouge,face_rouge, r_face_orange,face_orange);
        down_inverted( r_face_jaune,face_jaune,  r_face_blanche,  face_blanche,  r_face_verte, face_verte, r_face_rouge,face_rouge, r_face_orange,face_orange);
        left_inverted(r_face_jaune, face_jaune, r_face_bleue, face_bleue, r_face_blanche, face_blanche, r_face_verte, face_verte, r_face_rouge, face_rouge);
        left_inverted(r_face_jaune, face_jaune, r_face_bleue, face_bleue, r_face_blanche, face_blanche, r_face_verte, face_verte, r_face_rouge, face_rouge);}
