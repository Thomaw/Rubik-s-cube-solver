#include <Arduino.h>             // Permet d'accéder aux types et constantes standard du language Arduino
#include "movements.h"           // Permet d'accéder aux fonctions définies dans la bibliothèques "movements.h"
#include "rotation.h"            // Permet d'accéder aux fonctions définies dans la bibliothèques "rotation.h"
#include "fix_cross.h"           // Permet d'accéder aux fonctions définies dans la bibliothèques "fix_cross.h"
#include "fix_corners.h"         // Permet d'accéder aux fonctions définies dans la bibliothèques "fix_corners.h"
#include "fix_last_corners.h"    // Permet d'accéder aux fonctions définies dans la bibliothèques "fix_last_corners.h"
#include "affichage_cube.h"      // Permet d'accéder aux fonctions définies dans la bibliothèques "affichage_cube.h"
#include "edges.h"               // Permet d'accéder aux fonctions définies dans la bibliothèques "edges.h"
#include "white_cross.h"         // Permet d'accéder aux fonctions définies dans la bibliothèques "white_cross.h"
#include "solve_verification.h"  // Permet d'accéder aux variables définies dans le Header


// Création variable statique 
static int my_former_global;

// Fonction qui renvoie la varible statique 
int get_global_9() {
  return my_former_global;
  }

void set_global_9(int solve_stage) {
  if (solve_stage == 10 && my_former_global != 10) {my_former_global = 10;} // Si la cube a été réalisé, on passe à l'étape suivante
  }


void cube_decide_solved(int cube_solved, int solve_stage, char r_face_jaune[9], char face_jaune[9], char r_face_bleue[9], char face_bleue[9], char r_face_blanche[9], char face_blanche[9], char r_face_verte[9], char face_verte[9], char r_face_rouge[9], char face_rouge[9], char r_face_orange[9], char face_orange[9]) {
        
        Serial.println();
        Serial.println();
 
        // vérifie si toutes les faces ont la bonne couleur
        for(int i = 0; i < 9; i++){
                if (face_jaune[i] != 'y'){cube_solved = false;}      
                if (face_blanche[i] != 'w'){cube_solved = false;}
                if (face_bleue[i] != 'b'){cube_solved = false;}
                if (face_rouge[i] != 'r'){cube_solved = false;}
                if (face_verte[i] != 'g'){cube_solved = false;}
                if (face_orange[i] != 'o'){cube_solved = false;}}
        
        if (cube_solved == true){ Serial.println("The Whole Cube is solved!!!");}
        else{
                Serial.println("There is a problem: the cube isn't solved!"); // Erreur 
                cube_solved = false;
                }
                
        print_whole_cube(face_jaune, face_blanche, face_bleue, face_rouge, face_verte, face_orange);
        solve_stage = 10;
        set_global_9(solve_stage);
}
