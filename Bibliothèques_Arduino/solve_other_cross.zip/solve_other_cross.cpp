#include <Arduino.h>             // Permet d'accéder aux types et constantes standard du language Arduino 
#include "movements.h"           // Permet d'accéder aux fonctions définies dans la bibliothèques "movements.h"
#include "rotation.h"            // Permet d'accéder aux fonctions définies dans la bibliothèques "rotation.h"
#include "fix_cross.h"           // Permet d'accéder aux fonctions définies dans la bibliothèques "fix_cross.h"
#include "fix_corners.h"         // Permet d'accéder aux fonctions définies dans la bibliothèques "fix_corners.h"
#include "fix_last_corners.h"    // Permet d'accéder aux fonctions définies dans la bibliothèques "fix_last_corners.h"
#include "affichage_cube.h"      // Permet d'accéder aux fonctions définies dans la bibliothèques "affichage_cube.h"
#include "edges.h"               // Permet d'accéder aux fonctions définies dans la bibliothèques "edges.h"
#include "white_cross.h"         // Permet d'accéder aux fonctions définies dans la bibliothèques "white_cross.h"
#include "solve_other_cross.h"   // Permet d'accéder aux variables définies dans le Header

// Création variable statique 
static int my_former_global;

// Fonction qui renvoie la varible statique 
int get_global_5() {
  return my_former_global;
  }

void set_global_5(int solve_stage) {
  if (solve_stage == 6 && my_former_global != 6) {my_former_global = 6;}  // Si la croix a été réalisée, on passe à l'étape suivante
  }

void cube_decide_white_cross(int solve_stage, char r_face_jaune[9], char face_jaune[9], char r_face_bleue[9], char face_bleue[9], char r_face_blanche[9], char face_blanche[9], char r_face_verte[9], char face_verte[9], char r_face_rouge[9], char face_rouge[9], char r_face_orange[9], char face_orange[9]) {
        
        Serial.println();
        Serial.println();
        Serial.print("White Cross: ");
        if (solve_stage == 5 && face_blanche[1] == 'w' && face_blanche[3] == 'w' && face_blanche[5] == 'w' && face_blanche[7] == 'w'){
                Serial.print("Solved.");
                solve_stage = 6;
                set_global_5(solve_stage);} // Renvoie la variable solve_stage
                
        else if (face_bleue[1] == 'w' || face_rouge[1] == 'w' || face_verte[1] == 'w' || face_orange[1] == 'w'){
                /// Blanc sur des cubes connexes
                if(face_bleue[1] == 'w' && face_orange[1] == 'w'){
                        white_cross_on_top(r_face_jaune, face_jaune, r_face_bleue, face_bleue,  r_face_blanche, face_blanche, r_face_verte, face_verte, r_face_rouge,  face_rouge, r_face_orange, face_orange);}
                        
                else if(face_orange[1] == 'w' && face_verte[1] == 'w'){
                        back(r_face_bleue,face_bleue, r_face_orange, face_orange,  r_face_verte, face_verte, r_face_rouge, face_rouge, r_face_blanche, face_blanche);
                        white_cross_on_top(r_face_jaune, face_jaune, r_face_bleue, face_bleue,  r_face_blanche, face_blanche, r_face_verte, face_verte, r_face_rouge,  face_rouge, r_face_orange, face_orange);}
                        
                else if(face_verte[1] == 'w' && face_rouge[1] == 'w'){
                        back(r_face_bleue,face_bleue, r_face_orange, face_orange,  r_face_verte, face_verte, r_face_rouge, face_rouge, r_face_blanche, face_blanche);
                        back(r_face_bleue,face_bleue, r_face_orange, face_orange,  r_face_verte, face_verte, r_face_rouge, face_rouge, r_face_blanche, face_blanche);
                        white_cross_on_top(r_face_jaune, face_jaune, r_face_bleue, face_bleue,  r_face_blanche, face_blanche, r_face_verte, face_verte, r_face_rouge,  face_rouge, r_face_orange, face_orange);}
                        
                else if(face_rouge[1] == 'w' && face_bleue[1] == 'w'){
                        back_inverted(r_face_bleue, face_bleue, r_face_orange, face_orange, r_face_verte, face_verte, r_face_rouge, face_rouge, r_face_blanche, face_blanche);
                        white_cross_on_top(r_face_jaune, face_jaune, r_face_bleue, face_bleue,  r_face_blanche, face_blanche, r_face_verte, face_verte, r_face_rouge,  face_rouge, r_face_orange, face_orange);}
                        
                /// blanc sur des cubes non connexes
                else if(face_bleue[1] == 'w'){
                        white_cross_on_top(r_face_jaune, face_jaune, r_face_bleue, face_bleue,  r_face_blanche, face_blanche, r_face_verte, face_verte, r_face_rouge,  face_rouge, r_face_orange, face_orange);}
                        
                else if(face_verte[1] == 'w'){
                        back(r_face_bleue,face_bleue, r_face_orange, face_orange,  r_face_verte, face_verte, r_face_rouge, face_rouge, r_face_blanche, face_blanche);
                        back(r_face_bleue,face_bleue, r_face_orange, face_orange,  r_face_verte, face_verte, r_face_rouge, face_rouge, r_face_blanche, face_blanche);
                        white_cross_on_top(r_face_jaune, face_jaune, r_face_bleue, face_bleue,  r_face_blanche, face_blanche, r_face_verte, face_verte, r_face_rouge,  face_rouge, r_face_orange, face_orange);}
                        
                else if(face_rouge[1] == 'w'){
                        back_inverted(r_face_bleue, face_bleue, r_face_orange, face_orange, r_face_verte, face_verte, r_face_rouge, face_rouge, r_face_blanche, face_blanche);
                        white_cross_on_top(r_face_jaune, face_jaune, r_face_bleue, face_bleue,  r_face_blanche, face_blanche, r_face_verte, face_verte, r_face_rouge,  face_rouge, r_face_orange, face_orange);}
                        
                else if(face_orange[1] == 'w'){
                        back(r_face_bleue,face_bleue, r_face_orange, face_orange,  r_face_verte, face_verte, r_face_rouge, face_rouge, r_face_blanche, face_blanche);
                        white_cross_on_top(r_face_jaune, face_jaune, r_face_bleue, face_bleue,  r_face_blanche, face_blanche, r_face_verte, face_verte, r_face_rouge,  face_rouge, r_face_orange, face_orange);}
                else{Serial.println("No white cross");}
        }
}
