#include <Arduino.h>             // Permet d'accéder aux types et constantes standard du language Arduino
#include "movements.h"           // Permet d'accéder aux fonctions définies dans la bibliothèques "movements.h"
#include "rotation.h"            // Permet d'accéder aux fonctions définies dans la bibliothèques "rotation.h"
#include "fix_cross.h"           // Permet d'accéder aux fonctions définies dans la bibliothèques "fix_cross.h"
#include "fix_corners.h"         // Permet d'accéder aux fonctions définies dans la bibliothèques "fix_corners.h"
#include "fix_last_corners.h"    // Permet d'accéder aux fonctions définies dans la bibliothèques "fix_last_corners.h"
#include "affichage_cube.h"      // Permet d'accéder aux fonctions définies dans la bibliothèques "affichage_cube.h"
#include "edges.h"               // Permet d'accéder aux fonctions définies dans la bibliothèques "edges.h"
#include "white_cross.h"         // Permet d'accéder aux fonctions définies dans la bibliothèques "white_cross.h"
#include "solve_total_cross.h"   // Permet d'accéder aux variables définies dans le Header

// Création variable statique 
static int my_former_global;

// Fonction qui renvoie la varible statique 
int get_global_2() {
  return my_former_global;
  }

void set_global_2(int solve_stage) {
  if (solve_stage == 3 && my_former_global != 3) {my_former_global = 3;} // Si la croix orientée a été réalisée, on passe à l'étape suivante
  }
  


void cube_decide_whole_cross(int solve_stage, char r_face_jaune[9], char face_jaune[9], char r_face_bleue[9], char face_bleue[9], char r_face_blanche[9], char face_blanche[9], char r_face_verte[9], char face_verte[9], char r_face_rouge[9], char face_rouge[9], char r_face_orange[9], char face_orange[9]) {

        Serial.println();
        Serial.println();
        Serial.print("Whole Cross: ");
        if (solve_stage == 2 && face_bleue[7] == 'b' && face_rouge[7] == 'r' && face_verte[7] == 'g' && face_orange[7] == 'o'){
                Serial.print("Solved.");
                solve_stage = 3;
                set_global_2(solve_stage);} // Renvoie la variable solve_stage

        // Vert et orange bon
        else if (solve_stage == 2 && face_bleue[7] != 'b' && face_rouge[7] != 'r' && face_verte[7] == 'g' && face_orange[7] == 'o'){
                flip_cube( 'F',  r_face_jaune,  face_jaune,  r_face_bleue, face_bleue,  r_face_blanche,  face_blanche,  r_face_verte,  face_verte,  r_face_rouge, face_rouge,  r_face_orange,  face_orange);
                fix_cross_instance_1( r_face_jaune, face_jaune, r_face_bleue, face_bleue,  r_face_blanche, face_blanche, r_face_verte, face_verte, r_face_rouge,  face_rouge, r_face_orange, face_orange);
                flip_cube( 'f',  r_face_jaune,  face_jaune,  r_face_bleue, face_bleue,  r_face_blanche,  face_blanche,  r_face_verte,  face_verte,  r_face_rouge, face_rouge,  r_face_orange,  face_orange);}
                
        // Rouge et Orange bon
        else if (solve_stage == 2 && face_bleue[7] != 'b' && face_rouge[7] == 'r' && face_verte[7] != 'g' && face_orange[7] == 'o'){
                fix_cross_instance_2( r_face_jaune, face_jaune, r_face_bleue, face_bleue,  r_face_blanche, face_blanche, r_face_verte, face_verte, r_face_rouge,  face_rouge, r_face_orange, face_orange);}
                
        // red and green are good
        else if (solve_stage == 2 == true && face_bleue[7] != 'b' && face_rouge[7] == 'r' && face_verte[7] == 'g' && face_orange[7] != 'o'){
                fix_cross_instance_1( r_face_jaune, face_jaune, r_face_bleue, face_bleue,  r_face_blanche, face_blanche, r_face_verte, face_verte, r_face_rouge,  face_rouge, r_face_orange, face_orange);}
        
        // Bleu et orange bon
        else if (solve_stage == 2 && face_bleue[7] == 'b' && face_rouge[7] != 'r' && face_verte[7] != 'g' && face_orange[7] == 'o'){
                flip_cube( 'F',  r_face_jaune,  face_jaune,  r_face_bleue, face_bleue,  r_face_blanche,  face_blanche,  r_face_verte,  face_verte,  r_face_rouge, face_rouge,  r_face_orange,  face_orange);
                flip_cube( 'F',  r_face_jaune,  face_jaune,  r_face_bleue, face_bleue,  r_face_blanche,  face_blanche,  r_face_verte,  face_verte,  r_face_rouge, face_rouge,  r_face_orange,  face_orange);
                fix_cross_instance_1( r_face_jaune, face_jaune, r_face_bleue, face_bleue,  r_face_blanche, face_blanche, r_face_verte, face_verte, r_face_rouge,  face_rouge, r_face_orange, face_orange);
                flip_cube( 'f',  r_face_jaune,  face_jaune,  r_face_bleue, face_bleue,  r_face_blanche,  face_blanche,  r_face_verte,  face_verte,  r_face_rouge, face_rouge,  r_face_orange,  face_orange);
                flip_cube( 'f',  r_face_jaune,  face_jaune,  r_face_bleue, face_bleue,  r_face_blanche,  face_blanche,  r_face_verte,  face_verte,  r_face_rouge, face_rouge,  r_face_orange,  face_orange);}
        
        //Bleu et vert bon
        else if (solve_stage == 2 && face_bleue[7] == 'b' && face_rouge[7] != 'r' && face_verte[7] == 'g' && face_orange[7] != 'o'){
                flip_cube( 'F',  r_face_jaune,  face_jaune,  r_face_bleue, face_bleue,  r_face_blanche,  face_blanche,  r_face_verte,  face_verte,  r_face_rouge, face_rouge,  r_face_orange,  face_orange);
                fix_cross_instance_2( r_face_jaune, face_jaune, r_face_bleue, face_bleue,  r_face_blanche, face_blanche, r_face_verte, face_verte, r_face_rouge,  face_rouge, r_face_orange, face_orange);
                flip_cube( 'f',  r_face_jaune,  face_jaune,  r_face_bleue, face_bleue,  r_face_blanche,  face_blanche,  r_face_verte,  face_verte,  r_face_rouge, face_rouge,  r_face_orange,  face_orange);}
                
        // Rouge et bleu bon
        else if (solve_stage == 2 && face_bleue[7] == 'b' && face_rouge[7] == 'r' && face_verte[7] != 'g' && face_orange[7] != 'o'){
                flip_cube( 'f',  r_face_jaune,  face_jaune,  r_face_bleue, face_bleue,  r_face_blanche,  face_blanche,  r_face_verte,  face_verte,  r_face_rouge, face_rouge,  r_face_orange,  face_orange);
                fix_cross_instance_1( r_face_jaune, face_jaune, r_face_bleue, face_bleue,  r_face_blanche, face_blanche, r_face_verte, face_verte, r_face_rouge,  face_rouge, r_face_orange, face_orange);
                flip_cube( 'F',  r_face_jaune,  face_jaune,  r_face_bleue, face_bleue,  r_face_blanche,  face_blanche,  r_face_verte,  face_verte,  r_face_rouge, face_rouge,  r_face_orange,  face_orange);}
                
        // aucun résultat, erreur dans le cube
        else if (solve_stage == 2){front( r_face_bleue,  face_bleue,  r_face_orange,  face_orange,  r_face_verte, face_verte,  r_face_rouge,  face_rouge,  r_face_jaune,  face_jaune);}
        else{Serial.println("Error in whole_cross");}
}
