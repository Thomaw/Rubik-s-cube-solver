/*
  solve_total_cross.h - Bibliothèque permettant de décider
  quels mouvements réaliser pour obtenir la croix orientée de
  la première face 

  Créé par Dubouchet Thomas, 30 Décembre 2020
  Tout droit réservé
*/

/*
  Les procédures de cette bibliothèque seront en anglais car la terminologie utilisée
  est la terminologie officielle 

  
  Procédures de cette bibliothèque:

  void cube_decide_whole_cross
    - Fonction de décision pour rééaliser la première croix orientée

  void set_global_2(int n)
    - Fonction pour assurer le passage à l'étape de résolution suivante 

 */

// Les deux lignes ci-dessous permettent d'éviter les problèmes si quelqu'un inclut la bibliothèque deux fois.
#ifndef solve_total_cross_h
#define solve_total_cross_h

int get_global_2();

// ----------------------------------------------------------- //
// --------- Liste des procédures de la bibliothèque --------- //
// ----------------------------------------------------------- //

void set_global_2(int n);
void cube_decide_whole_cross(int solve_stage, char r_face_jaune[9], char face_jaune[9], char r_face_bleue[9], char face_bleue[9], char r_face_blanche[9], char face_blanche[9], char r_face_verte[9], char face_verte[9], char r_face_rouge[9], char face_rouge[9], char r_face_orange[9], char face_orange[9]);

#endif  // Fin de la création de la bibliothèque
