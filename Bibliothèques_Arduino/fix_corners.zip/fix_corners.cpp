#include <Arduino.h>    // Permets d'accéder aux types et constantes standard du language Arduino
#include "movements.h"  // Permets d'accéder aux fonctions définies dans la bibliothèques "movements.h" 
#include "fix_corners.h"// Permets d'accéder aux variables définies dans le Header

// Résolution des angles de la première face

// Réalise les mouvements suivants: U, B, U'
void fix_corners_instance_1(char r_face_jaune[9], char face_jaune[9], char r_face_bleue[9], char face_bleue[9], char r_face_blanche[9], char face_blanche[9], char r_face_verte[9], char face_verte[9], char r_face_rouge[9], char face_rouge[9], char r_face_orange[9], char face_orange[9]){ // top left
        Serial.println();
        Serial.print("  Fix Corners Instance 1: ");
        // cube simulation
        up(r_face_jaune, face_jaune, r_face_blanche, face_blanche, r_face_bleue, face_bleue, r_face_rouge, face_rouge, r_face_orange, face_orange);
        back(r_face_bleue,face_bleue, r_face_orange, face_orange,  r_face_verte, face_verte, r_face_rouge, face_rouge, r_face_blanche, face_blanche);
        up_inverted( r_face_jaune,face_jaune, r_face_blanche, face_blanche, r_face_bleue, face_bleue, r_face_rouge,face_rouge, r_face_orange, face_orange);}


// Réalise les mouvements suivants: U', B', U
void fix_corners_instance_2(char r_face_jaune[9], char face_jaune[9], char r_face_bleue[9], char face_bleue[9], char r_face_blanche[9], char face_blanche[9], char r_face_verte[9], char face_verte[9], char r_face_rouge[9], char face_rouge[9], char r_face_orange[9], char face_orange[9]){ // top right
        Serial.println();
        Serial.print("  Fix Corners Instance 2: ");
        // cube simulation
        up_inverted( r_face_jaune,face_jaune, r_face_blanche, face_blanche, r_face_bleue, face_bleue, r_face_rouge,face_rouge, r_face_orange, face_orange);
        back_inverted(r_face_bleue, face_bleue, r_face_orange, face_orange, r_face_verte, face_verte, r_face_rouge, face_rouge, r_face_blanche, face_blanche);
        up(r_face_jaune, face_jaune, r_face_blanche, face_blanche, r_face_bleue, face_bleue, r_face_rouge, face_rouge, r_face_orange, face_orange);}


// Réalise les mouvements suivants: L', B, L
void fix_corners_instance_3(char r_face_jaune[9], char face_jaune[9], char r_face_bleue[9], char face_bleue[9], char r_face_blanche[9], char face_blanche[9], char r_face_verte[9], char face_verte[9], char r_face_rouge[9], char face_rouge[9], char r_face_orange[9], char face_orange[9]){
        Serial.println();
        Serial.print("  Fix Corners Instance 3 (bring yellow piece up): ");

        // cube simulation
        left_inverted(r_face_jaune, face_jaune, r_face_bleue, face_bleue, r_face_blanche, face_blanche, r_face_verte, face_verte, r_face_rouge, face_rouge);
        back(r_face_bleue,face_bleue, r_face_orange, face_orange,  r_face_verte, face_verte, r_face_rouge, face_rouge, r_face_blanche, face_blanche);
        left(r_face_jaune, face_jaune, r_face_bleue, face_bleue, r_face_blanche, face_blanche, r_face_verte, face_verte, r_face_rouge, face_rouge);}
