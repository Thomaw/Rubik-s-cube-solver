#include <Arduino.h>             // Permet d'accéder aux types et constantes standard du language Arduino 
#include "movements.h"           // Permet d'accéder aux fonctions définies dans la bibliothèques "movements.h"
#include "rotation.h"            // Permet d'accéder aux fonctions définies dans la bibliothèques "rotation.h"
#include "fix_cross.h"           // Permet d'accéder aux fonctions définies dans la bibliothèques "fix_cross.h"
#include "fix_corners.h"         // Permet d'accéder aux fonctions définies dans la bibliothèques "fix_corners.h"
#include "fix_last_corners.h"    // Permet d'accéder aux fonctions définies dans la bibliothèques "fix_last_corners.h"
#include "affichage_cube.h"      // Permet d'accéder aux fonctions définies dans la bibliothèques "affichage_cube.h"
#include "edges.h"               // Permet d'accéder aux fonctions définies dans la bibliothèques "edges.h"
#include "white_cross.h"         // Permet d'accéder aux fonctions définies dans la bibliothèques "white_cross.h"
#include "solve_last_cube.h"     // Permet d'accéder aux variables définies dans le Header


// Création variable statique 
static int my_former_global;

// Fonction qui renvoie la varible statique 
int get_global_8() {
  return my_former_global;
  }

void set_global_8(int solve_stage) {
  if (solve_stage == 9 && my_former_global != 9) {my_former_global = 9;} // Si la croix a été réalisée, on passe à l'étape suivante
  }


void cube_decide_pll(int solve_stage, char r_face_jaune[9], char face_jaune[9], char r_face_bleue[9], char face_bleue[9], char r_face_blanche[9], char face_blanche[9], char r_face_verte[9], char face_verte[9], char r_face_rouge[9], char face_rouge[9], char r_face_orange[9], char face_orange[9]) {
        
        Serial.println();
        Serial.println();
        Serial.print("PLL: ");

        if (face_bleue[1] == 'b' && face_rouge[1] == 'r' && face_verte[1] == 'g' && face_orange[1] == 'o'){
                Serial.print("Solved.");
                solve_stage = 9;
                set_global_8(solve_stage);}
                
        else if (solve_stage == 8){      
                Serial.println("inside");
                // Rotation dans le sens contraire des aiguilles d'une montre
                if (face_rouge[1] == 'b' && face_bleue[1] == 'o' && face_orange[1] == 'r'){ccw_rotation(r_face_jaune, face_jaune, r_face_bleue, face_bleue,  r_face_blanche, face_blanche, r_face_verte, face_verte, r_face_rouge,  face_rouge, r_face_orange, face_orange);}
                        
                else if (face_verte[1] == 'r' && face_rouge[1] == 'b' && face_bleue[1] == 'g'){
                        flip_cube( 'F',  r_face_jaune,  face_jaune,  r_face_bleue, face_bleue,  r_face_blanche,  face_blanche,  r_face_verte,  face_verte,  r_face_rouge, face_rouge,  r_face_orange,  face_orange);
                        ccw_rotation(r_face_jaune, face_jaune, r_face_bleue, face_bleue,  r_face_blanche, face_blanche, r_face_verte, face_verte, r_face_rouge,  face_rouge, r_face_orange, face_orange);
                        flip_cube( 'f',  r_face_jaune,  face_jaune,  r_face_bleue, face_bleue,  r_face_blanche,  face_blanche,  r_face_verte,  face_verte,  r_face_rouge, face_rouge,  r_face_orange,  face_orange);}
                        
                else if (face_orange[1] == 'g' && face_verte[1] == 'r' && face_rouge[1] == 'o'){
                        flip_cube( 'F',  r_face_jaune,  face_jaune,  r_face_bleue, face_bleue,  r_face_blanche,  face_blanche,  r_face_verte,  face_verte,  r_face_rouge, face_rouge,  r_face_orange,  face_orange);
                        flip_cube( 'F',  r_face_jaune,  face_jaune,  r_face_bleue, face_bleue,  r_face_blanche,  face_blanche,  r_face_verte,  face_verte,  r_face_rouge, face_rouge,  r_face_orange,  face_orange);
                        ccw_rotation(r_face_jaune, face_jaune, r_face_bleue, face_bleue,  r_face_blanche, face_blanche, r_face_verte, face_verte, r_face_rouge,  face_rouge, r_face_orange, face_orange);
                        flip_cube( 'F',  r_face_jaune,  face_jaune,  r_face_bleue, face_bleue,  r_face_blanche,  face_blanche,  r_face_verte,  face_verte,  r_face_rouge, face_rouge,  r_face_orange,  face_orange);
                        flip_cube( 'F',  r_face_jaune,  face_jaune,  r_face_bleue, face_bleue,  r_face_blanche,  face_blanche,  r_face_verte,  face_verte,  r_face_rouge, face_rouge,  r_face_orange,  face_orange);}
                        
                else if (face_bleue[1] == 'o' && face_orange[1] == 'g' && face_verte[1] == 'b'){
                        flip_cube( 'f',  r_face_jaune,  face_jaune,  r_face_bleue, face_bleue,  r_face_blanche,  face_blanche,  r_face_verte,  face_verte,  r_face_rouge, face_rouge,  r_face_orange,  face_orange);
                        ccw_rotation(r_face_jaune, face_jaune, r_face_bleue, face_bleue,  r_face_blanche, face_blanche, r_face_verte, face_verte, r_face_rouge,  face_rouge, r_face_orange, face_orange);
                        flip_cube( 'F',  r_face_jaune,  face_jaune,  r_face_bleue, face_bleue,  r_face_blanche,  face_blanche,  r_face_verte,  face_verte,  r_face_rouge, face_rouge,  r_face_orange,  face_orange);}
 
                // Rotation dans le sens des aiguilles d'une montre
                else if (face_rouge[1] == 'o' && face_bleue[1] == 'r' && face_orange[1] == 'b'){cw_rotation(r_face_jaune, face_jaune, r_face_bleue, face_bleue,  r_face_blanche, face_blanche, r_face_verte, face_verte, r_face_rouge,  face_rouge, r_face_orange, face_orange);}
                        
                else if (face_verte[1] == 'b' && face_rouge[1] == 'g' && face_bleue[1] == 'r'){
                        flip_cube( 'F',  r_face_jaune,  face_jaune,  r_face_bleue, face_bleue,  r_face_blanche,  face_blanche,  r_face_verte,  face_verte,  r_face_rouge, face_rouge,  r_face_orange,  face_orange);
                        cw_rotation(r_face_jaune, face_jaune, r_face_bleue, face_bleue,  r_face_blanche, face_blanche, r_face_verte, face_verte, r_face_rouge,  face_rouge, r_face_orange, face_orange);
                        flip_cube( 'f',  r_face_jaune,  face_jaune,  r_face_bleue, face_bleue,  r_face_blanche,  face_blanche,  r_face_verte,  face_verte,  r_face_rouge, face_rouge,  r_face_orange,  face_orange);}
                        
                else if (face_orange[1] == 'r' && face_verte[1] == 'o' && face_rouge[1] == 'g'){
                        flip_cube( 'F',  r_face_jaune,  face_jaune,  r_face_bleue, face_bleue,  r_face_blanche,  face_blanche,  r_face_verte,  face_verte,  r_face_rouge, face_rouge,  r_face_orange,  face_orange);
                        flip_cube( 'F',  r_face_jaune,  face_jaune,  r_face_bleue, face_bleue,  r_face_blanche,  face_blanche,  r_face_verte,  face_verte,  r_face_rouge, face_rouge,  r_face_orange,  face_orange);
                        cw_rotation(r_face_jaune, face_jaune, r_face_bleue, face_bleue,  r_face_blanche, face_blanche, r_face_verte, face_verte, r_face_rouge,  face_rouge, r_face_orange, face_orange);
                        flip_cube( 'F',  r_face_jaune,  face_jaune,  r_face_bleue, face_bleue,  r_face_blanche,  face_blanche,  r_face_verte,  face_verte,  r_face_rouge, face_rouge,  r_face_orange,  face_orange);
                        flip_cube( 'F',  r_face_jaune,  face_jaune,  r_face_bleue, face_bleue,  r_face_blanche,  face_blanche,  r_face_verte,  face_verte,  r_face_rouge, face_rouge,  r_face_orange,  face_orange);}
                        
                else if (face_bleue[1] == 'g' && face_orange[1] == 'b' && face_verte[1] == 'o'){
                        flip_cube( 'f',  r_face_jaune,  face_jaune,  r_face_bleue, face_bleue,  r_face_blanche,  face_blanche,  r_face_verte,  face_verte,  r_face_rouge, face_rouge,  r_face_orange,  face_orange);
                        cw_rotation(r_face_jaune, face_jaune, r_face_bleue, face_bleue,  r_face_blanche, face_blanche, r_face_verte, face_verte, r_face_rouge,  face_rouge, r_face_orange, face_orange);
                        flip_cube( 'F',  r_face_jaune,  face_jaune,  r_face_bleue, face_bleue,  r_face_blanche,  face_blanche,  r_face_verte,  face_verte,  r_face_rouge, face_rouge,  r_face_orange,  face_orange);}
                        
                // Les quatre angles sont mal placés
                else if (face_bleue[1] != 'b' && face_rouge[1] != 'r' && face_verte[1] != 'g' && face_orange[1] != 'o'){
                        cw_rotation(r_face_jaune, face_jaune, r_face_bleue, face_bleue,  r_face_blanche, face_blanche, r_face_verte, face_verte, r_face_rouge,  face_rouge, r_face_orange, face_orange);}
                        
                else{Serial.println("Problem in Pll (else statement reached)");}
        } 
        else{Serial.println("Error in pll_case_check()");}  // Erreur
}
