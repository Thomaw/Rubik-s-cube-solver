#include <Arduino.h>             // Permet d'accéder aux types et constantes standard du language Arduino
#include "movements.h"           // Permet d'accéder aux fonctions définies dans la bibliothèques "movements.h"
#include "rotation.h"            // Permet d'accéder aux fonctions définies dans la bibliothèques "rotation.h"
#include "fix_cross.h"           // Permet d'accéder aux fonctions définies dans la bibliothèques "fix_cross.h"
#include "fix_corners.h"         // Permet d'accéder aux fonctions définies dans la bibliothèques "fix_corners.h"
#include "fix_last_corners.h"    // Permet d'accéder aux fonctions définies dans la bibliothèques "fix_last_corners.h"
#include "affichage_cube.h"      // Permet d'accéder aux fonctions définies dans la bibliothèques "affichage_cube.h"
#include "edges.h"               // Permet d'accéder aux fonctions définies dans la bibliothèques "edges.h"
#include "white_cross.h"         // Permet d'accéder aux fonctions définies dans la bibliothèques "white_cross.h"
#include "solve_cross.h"         // Permet d'accéder aux variables définies dans le Header


// Création variable statique 
static int my_former_global;

// Fonction qui renvoie la varible statique 
int get_global_1() {
  return my_former_global;
  }

void set_global_1(int solve_stage) {
  if (solve_stage == 2 && my_former_global != 2) {my_former_global = 2;}  // Si la croix a été réalisée, on passe à l'étape suivante
  }
  

void cube_decide_cross(int solve_stage, char r_face_jaune[9], char face_jaune[9], char r_face_bleue[9], char face_bleue[9], char r_face_blanche[9], char face_blanche[9], char r_face_verte[9], char face_verte[9], char r_face_rouge[9], char face_rouge[9], char r_face_orange[9], char face_orange[9]) {

        Serial.println();
        Serial.println();
        Serial.print("Cross: ");
        if (solve_stage == 1 && face_jaune[1] == 'y' && face_jaune[3] == 'y' && face_jaune[5] == 'y' && face_jaune[7] == 'y'){ // Si la croix est résolue 
                Serial.print("Solved.");
                solve_stage = 2;
                set_global_1(solve_stage);} // Renvoie la variable solve_stage
                
        else if(solve_stage == 1){
                // Fface_bleue[3]
                if (face_bleue[3] == 'y'){
                        for(int x = 0; x < 3; x++){ // faire tourner le cube quatre fois, ou jusqu'à ce qu'il y ait un espace vide
                                if (face_jaune[3] != 'y'){
                                        left(r_face_jaune, face_jaune, r_face_bleue, face_bleue, r_face_blanche, face_blanche, r_face_verte, face_verte, r_face_rouge, face_rouge);
                                        x = 3;} // boucle finale puisque la pièce jaune a atteint le sommet
                                else{front( r_face_bleue,  face_bleue,  r_face_orange,  face_orange,  r_face_verte, face_verte,  r_face_rouge,  face_rouge,  r_face_jaune,  face_jaune);}
                        }
                }
                // Face_bleue[5]
                else if (face_bleue[5] == 'y'){
                        for(int x = 0; x < 3; x++){ // faire tourner le cube quatre fois, ou jusqu'à ce qu'il y ait un espace vide
                                if (face_jaune[5] != 'y'){
                                        right_inverted( r_face_jaune, face_jaune, r_face_bleue,face_bleue, r_face_blanche, face_blanche, r_face_verte, face_verte, r_face_orange,face_orange);
                                        x = 3;} // boucle finale puisque la pièce jaune a atteint le sommet
                                else{front( r_face_bleue,  face_bleue,  r_face_orange,  face_orange,  r_face_verte, face_verte,  r_face_rouge,  face_rouge,  r_face_jaune,  face_jaune);}
                        }
                }
                // Face_rouge[5]
                else if (face_rouge[5] == 'y'){
                        for(int x = 0; x < 3; x++){ // faire tourner le cube quatre fois, ou jusqu'à ce qu'il y ait un espace vide
                                if (face_jaune[1] != 'y'){
                                        up_inverted( r_face_jaune,face_jaune, r_face_blanche, face_blanche, r_face_bleue, face_bleue, r_face_rouge,face_rouge, r_face_orange, face_orange);
                                        x = 3;} // boucle finale puisque la pièce jaune a atteint le sommet
                                else{front( r_face_bleue,  face_bleue,  r_face_orange,  face_orange,  r_face_verte, face_verte,  r_face_rouge,  face_rouge,  r_face_jaune,  face_jaune);}
                        }
                }
                // Face_rouge[3]
                else if (face_rouge[3] == 'y'){
                        for(int x = 0; x < 3; x++){ // faire tourner le cube quatre fois, ou jusqu'à ce qu'il y ait un espace vide
                                if (face_jaune[7] != 'y'){
                                        down( r_face_jaune, face_jaune, r_face_blanche, face_blanche,  r_face_verte, face_verte,  r_face_rouge, face_rouge, r_face_orange, face_orange);
                                        x = 3;} // boucle finale puisque la pièce jaune a atteint le sommet
                                else{front( r_face_bleue,  face_bleue,  r_face_orange,  face_orange,  r_face_verte, face_verte,  r_face_rouge,  face_rouge,  r_face_jaune,  face_jaune);}
                        }
                }
                // Face_verte[5]
                else if (face_verte[5] == 'y'){
                        for(int x = 0; x < 3; x++){ // faire tourner le cube quatre fois, ou jusqu'à ce qu'il y ait un espace vide
                                if (face_jaune[3] != 'y'){
                                        left_inverted(r_face_jaune, face_jaune, r_face_bleue, face_bleue, r_face_blanche, face_blanche, r_face_verte, face_verte, r_face_rouge, face_rouge);
                                        x = 3;} // boucle finale puisque la pièce jaune a atteint le sommet
                                else{front( r_face_bleue,  face_bleue,  r_face_orange,  face_orange,  r_face_verte, face_verte,  r_face_rouge,  face_rouge,  r_face_jaune,  face_jaune);}
                        }
                }
 
                // Face_verte[3]
                else if (face_verte[3] == 'y'){
                        for(int x = 0; x < 3; x++){ // faire tourner le cube quatre fois, ou jusqu'à ce qu'il y ait un espace vide
                                if (face_jaune[5] != 'y'){
                                        right(r_face_jaune,face_jaune,r_face_bleue,face_bleue,r_face_blanche,face_blanche,r_face_verte, face_verte,r_face_orange,face_orange);
                                        x = 3;} // boucle finale puisque la pièce jaune a atteint le sommet
                                else{front( r_face_bleue,  face_bleue,  r_face_orange,  face_orange,  r_face_verte, face_verte,  r_face_rouge,  face_rouge,  r_face_jaune,  face_jaune);}
                        }
                }
                // Face_orange[5]
                else if (face_orange[5] == 'y'){
                        for(int x = 0; x < 3; x++){ // faire tourner le cube quatre fois, ou jusqu'à ce qu'il y ait un espace vide
                                if (face_jaune[7] != 'y'){
                                        down_inverted( r_face_jaune,face_jaune,  r_face_blanche,  face_blanche,  r_face_verte, face_verte, r_face_rouge,face_rouge, r_face_orange,face_orange);
                                        x = 3;}// boucle finale puisque la pièce jaune a atteint le sommet
                                else{front( r_face_bleue,  face_bleue,  r_face_orange,  face_orange,  r_face_verte, face_verte,  r_face_rouge,  face_rouge,  r_face_jaune,  face_jaune);}
                        }
                }
                // Face_orange[3]
                else if (face_orange[3] == 'y'){
                        for(int x = 0; x < 3; x++){ // faire tourner le cube quatre fois, ou jusqu'à ce qu'il y ait un espace vide
                                if (face_jaune[1] != 'y'){
                                        up(r_face_jaune, face_jaune, r_face_blanche, face_blanche, r_face_bleue, face_bleue, r_face_rouge, face_rouge, r_face_orange, face_orange);
                                        x = 3;}// boucle finale puisque la pièce jaune a atteint le sommet
                                else{front( r_face_bleue,  face_bleue,  r_face_orange,  face_orange,  r_face_verte, face_verte,  r_face_rouge,  face_rouge,  r_face_jaune,  face_jaune);}
                        }
                }
                // Face_blanche[1]
                else if (face_blanche[1] == 'y'){
                        for(int x = 0; x < 3; x++){ // faire tourner le cube quatre fois, ou jusqu'à ce qu'il y ait un espace vide
                                if (face_jaune[7] != 'y'){
                                        down( r_face_jaune, face_jaune, r_face_blanche, face_blanche,  r_face_verte, face_verte,  r_face_rouge, face_rouge, r_face_orange, face_orange);
                                        down( r_face_jaune, face_jaune, r_face_blanche, face_blanche,  r_face_verte, face_verte,  r_face_rouge, face_rouge, r_face_orange, face_orange);
                                        x = 3;} // boucle finale puisque la pièce jaune a atteint le sommet
                                else{front( r_face_bleue,  face_bleue,  r_face_orange,  face_orange,  r_face_verte, face_verte,  r_face_rouge,  face_rouge,  r_face_jaune,  face_jaune);}
                        }
                }
                // Face_blanche[7]
                else if (face_blanche[7] == 'y'){
                        for(int x = 0; x < 3; x++){ // faire tourner le cube quatre fois, ou jusqu'à ce qu'il y ait un espace vide
                                if (face_jaune[1] != 'y'){
                                        up(r_face_jaune, face_jaune, r_face_blanche, face_blanche, r_face_bleue, face_bleue, r_face_rouge, face_rouge, r_face_orange, face_orange);
                                        up(r_face_jaune, face_jaune, r_face_blanche, face_blanche, r_face_bleue, face_bleue, r_face_rouge, face_rouge, r_face_orange, face_orange);
                                        x = 3;} // boucle finale puisque la pièce jaune a atteint le sommet
                                else{front( r_face_bleue,  face_bleue,  r_face_orange,  face_orange,  r_face_verte, face_verte,  r_face_rouge,  face_rouge,  r_face_jaune,  face_jaune);}
                        }
                }
                // Face_blanche[3]
                else if (face_blanche[3] == 'y'){
                        for(int x = 0; x < 3; x++){ // faire tourner le cube quatre fois, ou jusqu'à ce qu'il y ait un espace vide
                                if (face_jaune[3] != 'y'){
                                        left(r_face_jaune, face_jaune, r_face_bleue, face_bleue, r_face_blanche, face_blanche, r_face_verte, face_verte, r_face_rouge, face_rouge);
                                        left(r_face_jaune, face_jaune, r_face_bleue, face_bleue, r_face_blanche, face_blanche, r_face_verte, face_verte, r_face_rouge, face_rouge);
                                        x = 3;} // boucle finale puisque la pièce jaune a atteint le sommet
                                else{front( r_face_bleue,  face_bleue,  r_face_orange,  face_orange,  r_face_verte, face_verte,  r_face_rouge,  face_rouge,  r_face_jaune,  face_jaune);}
                        }
                }
                // Face_blanche[5]
                else if (face_blanche[5] == 'y'){
                        for(int x = 0; x < 3; x++){ // faire tourner le cube quatre fois, ou jusqu'à ce qu'il y ait un espace vide
                          if (face_jaune[5] != 'y'){
                                        right(r_face_jaune,face_jaune,r_face_bleue,face_bleue,r_face_blanche,face_blanche,r_face_verte, face_verte,r_face_orange,face_orange);
                                        right(r_face_jaune,face_jaune,r_face_bleue,face_bleue,r_face_blanche,face_blanche,r_face_verte, face_verte,r_face_orange,face_orange);
                                        x = 3;} // boucle finale puisque la pièce jaune a atteint le sommet
                                else{front( r_face_bleue,  face_bleue,  r_face_orange,  face_orange,  r_face_verte, face_verte,  r_face_rouge,  face_rouge,  r_face_jaune,  face_jaune);}
                        }
                }
                
                // Face_bleue[1]
                else if (face_bleue[1] == 'y'){
                        for(int x = 0; x < 3; x++){ // faire tourner le cube quatre fois, ou jusqu'à ce qu'il y ait un espace vide
                                if (face_jaune[1] != 'y'){
                                        up(r_face_jaune, face_jaune, r_face_blanche, face_blanche, r_face_bleue, face_bleue, r_face_rouge, face_rouge, r_face_orange, face_orange);
                                        front( r_face_bleue,  face_bleue,  r_face_orange,  face_orange,  r_face_verte, face_verte,  r_face_rouge,  face_rouge,  r_face_jaune,  face_jaune);
                                        right_inverted( r_face_jaune, face_jaune, r_face_bleue,face_bleue, r_face_blanche, face_blanche, r_face_verte, face_verte, r_face_orange,face_orange);
                                        x = 3;} // boucle finale puisque la pièce jaune a atteint le sommet
                                else{front( r_face_bleue,  face_bleue,  r_face_orange,  face_orange,  r_face_verte, face_verte,  r_face_rouge,  face_rouge,  r_face_jaune,  face_jaune);}
                        }
                }
                // Face_bleue[7]
                else if (face_bleue[7] == 'y'){
                        if (face_jaune[1] != 'y'){
                                up_inverted( r_face_jaune,face_jaune, r_face_blanche, face_blanche, r_face_bleue, face_bleue, r_face_rouge,face_rouge, r_face_orange, face_orange);
                                front( r_face_bleue,  face_bleue,  r_face_orange,  face_orange,  r_face_verte, face_verte,  r_face_rouge,  face_rouge,  r_face_jaune,  face_jaune);
                                right_inverted( r_face_jaune, face_jaune, r_face_bleue,face_bleue, r_face_blanche, face_blanche, r_face_verte, face_verte, r_face_orange,face_orange);}
                        else{up_inverted( r_face_jaune,face_jaune, r_face_blanche, face_blanche, r_face_bleue, face_bleue, r_face_rouge,face_rouge, r_face_orange, face_orange);}
                }
                // Face_rouge[1]
                else if (face_rouge[1] == 'y'){
                        for(int x = 0; x < 3; x++){ // faire tourner le cube quatre fois, ou jusqu'à ce qu'il y ait un espace vide
                                if (face_jaune[3] != 'y'){
                                        left(r_face_jaune, face_jaune, r_face_bleue, face_bleue, r_face_blanche, face_blanche, r_face_verte, face_verte, r_face_rouge, face_rouge);
                                        front( r_face_bleue,  face_bleue,  r_face_orange,  face_orange,  r_face_verte, face_verte,  r_face_rouge,  face_rouge,  r_face_jaune,  face_jaune);
                                        up_inverted( r_face_jaune,face_jaune, r_face_blanche, face_blanche, r_face_bleue, face_bleue, r_face_rouge,face_rouge, r_face_orange, face_orange);
                                        x = 3;} // boucle finale puisque la pièce jaune a atteint le sommet
                                else{front( r_face_bleue,  face_bleue,  r_face_orange,  face_orange,  r_face_verte, face_verte,  r_face_rouge,  face_rouge,  r_face_jaune,  face_jaune);}
                        }
                }
                // Face_rouge[7]
                else if (face_rouge[7] == 'y'){
                        if (face_jaune[3] != 'y'){
                                left_inverted(r_face_jaune, face_jaune, r_face_bleue, face_bleue, r_face_blanche, face_blanche, r_face_verte, face_verte, r_face_rouge, face_rouge);
                                front( r_face_bleue,  face_bleue,  r_face_orange,  face_orange,  r_face_verte, face_verte,  r_face_rouge,  face_rouge,  r_face_jaune,  face_jaune);
                                up_inverted( r_face_jaune,face_jaune, r_face_blanche, face_blanche, r_face_bleue, face_bleue, r_face_rouge,face_rouge, r_face_orange, face_orange);}
                        else{left_inverted(r_face_jaune, face_jaune, r_face_bleue, face_bleue, r_face_blanche, face_blanche, r_face_verte, face_verte, r_face_rouge, face_rouge);}
                }
                // Face_verte[1]
                else if (face_verte[1] == 'y'){
                        for(int x = 0; x < 3; x++){ // faire tourner le cube quatre fois, ou jusqu'à ce qu'il y ait un espace vide
                                if (face_jaune[7] != 'y'){
                                        down( r_face_jaune, face_jaune, r_face_blanche, face_blanche,  r_face_verte, face_verte,  r_face_rouge, face_rouge, r_face_orange, face_orange);
                                        front( r_face_bleue,  face_bleue,  r_face_orange,  face_orange,  r_face_verte, face_verte,  r_face_rouge,  face_rouge,  r_face_jaune,  face_jaune);
                                        left_inverted(r_face_jaune, face_jaune, r_face_bleue, face_bleue, r_face_blanche, face_blanche, r_face_verte, face_verte, r_face_rouge, face_rouge);
                                        x = 3;} // boucle finale puisque la pièce jaune a atteint le sommet
                                else{front( r_face_bleue,  face_bleue,  r_face_orange,  face_orange,  r_face_verte, face_verte,  r_face_rouge,  face_rouge,  r_face_jaune,  face_jaune);}
                        }
                }
                // face_verte[7]
                else if (face_verte[7] == 'y'){
                        if (face_jaune[7] != 'y'){
                                down( r_face_jaune, face_jaune, r_face_blanche, face_blanche,  r_face_verte, face_verte,  r_face_rouge, face_rouge, r_face_orange, face_orange);
                                front_inverted( r_face_bleue,  face_bleue,  r_face_orange,  face_orange,  r_face_verte,  face_verte,  r_face_rouge, face_rouge,  r_face_jaune,  face_jaune);
                                right(r_face_jaune,face_jaune,r_face_bleue,face_bleue,r_face_blanche,face_blanche,r_face_verte, face_verte,r_face_orange,face_orange);}                        
                        else{down( r_face_jaune, face_jaune, r_face_blanche, face_blanche,  r_face_verte, face_verte,  r_face_rouge, face_rouge, r_face_orange, face_orange);}
                }
                // Face_orange[1]
                else if (face_orange[1] == 'y'){
                        for(int x = 0; x < 3; x++){ // faire tourner le cube quatre fois, ou jusqu'à ce qu'il y ait un espace vide
                                if (face_jaune[5] != 'y'){
                                        right(r_face_jaune,face_jaune,r_face_bleue,face_bleue,r_face_blanche,face_blanche,r_face_verte, face_verte,r_face_orange,face_orange);
                                        front( r_face_bleue,  face_bleue,  r_face_orange,  face_orange,  r_face_verte, face_verte,  r_face_rouge,  face_rouge,  r_face_jaune,  face_jaune);
                                        down_inverted( r_face_jaune,face_jaune,  r_face_blanche,  face_blanche,  r_face_verte, face_verte, r_face_rouge,face_rouge, r_face_orange,face_orange);
                                        x = 3;} // boucle finale puisque la pièce jaune a atteint le sommet
                                else{front( r_face_bleue,  face_bleue,  r_face_orange,  face_orange,  r_face_verte, face_verte,  r_face_rouge,  face_rouge,  r_face_jaune,  face_jaune);}
                        }
                }
                // Face_verte[7]
                else if (face_orange[7] == 'y'){
                        if (face_jaune[5] != 'y'){
                                right_inverted( r_face_jaune, face_jaune, r_face_bleue,face_bleue, r_face_blanche, face_blanche, r_face_verte, face_verte, r_face_orange,face_orange);
                                front( r_face_bleue,  face_bleue,  r_face_orange,  face_orange,  r_face_verte, face_verte,  r_face_rouge,  face_rouge,  r_face_jaune,  face_jaune);
                                down_inverted( r_face_jaune,face_jaune,  r_face_blanche,  face_blanche,  r_face_verte, face_verte, r_face_rouge,face_rouge, r_face_orange,face_orange);}
                        else{right_inverted( r_face_jaune, face_jaune, r_face_bleue,face_bleue, r_face_blanche, face_blanche, r_face_verte, face_verte, r_face_orange,face_orange);}
                }
        }
}
