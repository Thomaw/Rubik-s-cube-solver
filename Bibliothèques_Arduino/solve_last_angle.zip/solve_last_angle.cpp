#include <Arduino.h>             // Permet d'accéder aux types et constantes standard du language Arduino 
#include "movements.h"           // Permet d'accéder aux fonctions définies dans la bibliothèques "movements.h"
#include "rotation.h"            // Permet d'accéder aux fonctions définies dans la bibliothèques "rotation.h"
#include "fix_cross.h"           // Permet d'accéder aux fonctions définies dans la bibliothèques "fix_cross.h"
#include "fix_corners.h"         // Permet d'accéder aux fonctions définies dans la bibliothèques "fix_corners.h"
#include "fix_last_corners.h"    // Permet d'accéder aux fonctions définies dans la bibliothèques "fix_last_corners.h"
#include "affichage_cube.h"      // Permet d'accéder aux fonctions définies dans la bibliothèques "affichage_cube.h"
#include "edges.h"               // Permet d'accéder aux fonctions définies dans la bibliothèques "edges.h"
#include "white_cross.h"         // Permet d'accéder aux fonctions définies dans la bibliothèques "white_cross.h"
#include "solve_last_angle.h"    // Permet d'accéder aux variables définies dans le Header

// Création variable statique 
static int my_former_global;

// Fonction qui renvoie la varible statique 
int get_global_7() {
  return my_former_global;
  }

void set_global_7(int solve_stage) {
  if (solve_stage == 8 && my_former_global != 8) {my_former_global = 8;}  // Si la croix a été réalisée, on passe à l'étape suivante
  }

void cube_decide_oll(int solve_stage, char r_face_jaune[9], char face_jaune[9], char r_face_bleue[9], char face_bleue[9], char r_face_blanche[9], char face_blanche[9], char r_face_verte[9], char face_verte[9], char r_face_rouge[9], char face_rouge[9], char r_face_orange[9], char face_orange[9]) {
        
        Serial.println();
        Serial.println();
        Serial.print("OLL: ");
        //
        if (face_verte[0] == 'o' && face_verte[2] == 'o' && face_rouge[0] == 'g' && face_rouge[2] == 'g' &&
                face_bleue[0] == 'r' && face_bleue[2] == 'r' && face_orange[0] == 'b' && face_orange[2] == 'b'){
                back(r_face_bleue,face_bleue, r_face_orange, face_orange,  r_face_verte, face_verte, r_face_rouge, face_rouge, r_face_blanche, face_blanche);}
                
        else if(face_verte[0] == 'b' && face_verte[2] == 'b' && face_rouge[0] == 'o' && face_rouge[2] == 'o' &&
                        face_bleue[0] == 'g' && face_bleue[2] == 'g' && face_orange[0] == 'r' && face_orange[2] == 'r'){
                back(r_face_bleue,face_bleue, r_face_orange, face_orange,  r_face_verte, face_verte, r_face_rouge, face_rouge, r_face_blanche, face_blanche);
                back(r_face_bleue,face_bleue, r_face_orange, face_orange,  r_face_verte, face_verte, r_face_rouge, face_rouge, r_face_blanche, face_blanche);}
                
        else if(face_verte[0] == 'r' && face_verte[2] == 'r' && face_rouge[0] == 'b' && face_rouge[2] == 'b' &&
                    face_bleue[0] == 'o' && face_bleue[2] == 'o' && face_orange[0] == 'g' && face_orange[2] == 'g'){
                back_inverted(r_face_bleue, face_bleue, r_face_orange, face_orange, r_face_verte, face_verte, r_face_rouge, face_rouge, r_face_blanche, face_blanche);}
 
        if (face_verte[0] == 'g' && face_verte[2] == 'g' && face_rouge[0] == 'r' && face_rouge[2] == 'r' &&
                face_bleue[0] == 'b' && face_bleue[2] == 'b' && face_orange[0] == 'o' && face_orange[2] == 'o'){
                Serial.print("Solved.");
                solve_stage = 8;
                set_global_7(solve_stage);}
 
        else if(solve_stage == 7){
                // gvert sur les cubes de droite
                if (face_bleue[0] == 'b' && face_bleue[2] == 'g' && face_orange[2] == 'b'){
                        green_on_right(r_face_jaune, face_jaune, r_face_bleue, face_bleue,  r_face_blanche, face_blanche, r_face_verte, face_verte, r_face_rouge,  face_rouge, r_face_orange, face_orange);}
                        
                else if (face_rouge[0] == 'b' && face_rouge[2] == 'g' && face_bleue[2] == 'b'){
                        back_inverted(r_face_bleue, face_bleue, r_face_orange, face_orange, r_face_verte, face_verte, r_face_rouge, face_rouge, r_face_blanche, face_blanche);
                        green_on_right(r_face_jaune, face_jaune, r_face_bleue, face_bleue,  r_face_blanche, face_blanche, r_face_verte, face_verte, r_face_rouge,  face_rouge, r_face_orange, face_orange);}
                        
                else if (face_verte[0] == 'b' && face_verte[2] == 'g' && face_rouge[2] == 'b'){
                        back(r_face_bleue,face_bleue, r_face_orange, face_orange,  r_face_verte, face_verte, r_face_rouge, face_rouge, r_face_blanche, face_blanche);
                        back(r_face_bleue,face_bleue, r_face_orange, face_orange,  r_face_verte, face_verte, r_face_rouge, face_rouge, r_face_blanche, face_blanche);
                        green_on_right(r_face_jaune, face_jaune, r_face_bleue, face_bleue,  r_face_blanche, face_blanche, r_face_verte, face_verte, r_face_rouge,  face_rouge, r_face_orange, face_orange);}
                        
                else if (face_orange[0] == 'b' && face_orange[2] == 'g' && face_verte[2] == 'b'){
                        back(r_face_bleue,face_bleue, r_face_orange, face_orange,  r_face_verte, face_verte, r_face_rouge, face_rouge, r_face_blanche, face_blanche);
                        green_on_right(r_face_jaune, face_jaune, r_face_bleue, face_bleue,  r_face_blanche, face_blanche, r_face_verte, face_verte, r_face_rouge,  face_rouge, r_face_orange, face_orange);}
 
                // vert sur les cubes de gauche
                else if (face_bleue[0] == 'g' && face_bleue[2] == 'b' && face_rouge[0] == 'b'){
                        green_on_left(r_face_jaune, face_jaune, r_face_bleue, face_bleue,  r_face_blanche, face_blanche, r_face_verte, face_verte, r_face_rouge,  face_rouge, r_face_orange, face_orange);}
                        
                else if (face_rouge[0] == 'g' && face_rouge[2] == 'b' && face_verte[0] == 'b'){
                        back_inverted(r_face_bleue, face_bleue, r_face_orange, face_orange, r_face_verte, face_verte, r_face_rouge, face_rouge, r_face_blanche, face_blanche);
                        green_on_left(r_face_jaune, face_jaune, r_face_bleue, face_bleue,  r_face_blanche, face_blanche, r_face_verte, face_verte, r_face_rouge,  face_rouge, r_face_orange, face_orange);}
                        
                else if (face_verte[0] == 'g' && face_verte[2] == 'b' && face_orange[0] == 'b'){
                        back(r_face_bleue,face_bleue, r_face_orange, face_orange,  r_face_verte, face_verte, r_face_rouge, face_rouge, r_face_blanche, face_blanche);
                        back(r_face_bleue,face_bleue, r_face_orange, face_orange,  r_face_verte, face_verte, r_face_rouge, face_rouge, r_face_blanche, face_blanche);
                        green_on_left(r_face_jaune, face_jaune, r_face_bleue, face_bleue,  r_face_blanche, face_blanche, r_face_verte, face_verte, r_face_rouge,  face_rouge, r_face_orange, face_orange);}
                        
                else if (face_orange[0] == 'g' && face_orange[2] == 'b' && face_bleue[0] == 'b'){
                        back(r_face_bleue,face_bleue, r_face_orange, face_orange,  r_face_verte, face_verte, r_face_rouge, face_rouge, r_face_blanche, face_blanche);
                        green_on_left(r_face_jaune, face_jaune, r_face_bleue, face_bleue,  r_face_blanche, face_blanche, r_face_verte, face_verte, r_face_rouge,  face_rouge, r_face_orange, face_orange);}
                        
                //// Si rien ne marche 
                // vert à droite
                else{
                        Serial.println("last resort");
                        if (face_bleue[2] == 'g'){
                                green_on_right(r_face_jaune, face_jaune, r_face_bleue, face_bleue,  r_face_blanche, face_blanche, r_face_verte, face_verte, r_face_rouge,  face_rouge, r_face_orange, face_orange);}
                                
                        else if(face_orange[2] == 'g'){
                                back(r_face_bleue,face_bleue, r_face_orange, face_orange,  r_face_verte, face_verte, r_face_rouge, face_rouge, r_face_blanche, face_blanche);
                                green_on_right(r_face_jaune, face_jaune, r_face_bleue, face_bleue,  r_face_blanche, face_blanche, r_face_verte, face_verte, r_face_rouge,  face_rouge, r_face_orange, face_orange);}
                                
                        else if(face_verte[2] == 'g'){
                                back(r_face_bleue,face_bleue, r_face_orange, face_orange,  r_face_verte, face_verte, r_face_rouge, face_rouge, r_face_blanche, face_blanche);
                                back(r_face_bleue,face_bleue, r_face_orange, face_orange,  r_face_verte, face_verte, r_face_rouge, face_rouge, r_face_blanche, face_blanche);
                                green_on_right(r_face_jaune, face_jaune, r_face_bleue, face_bleue,  r_face_blanche, face_blanche, r_face_verte, face_verte, r_face_rouge,  face_rouge, r_face_orange, face_orange);}
                                
                        else if(face_rouge[2] == 'g'){
                                back_inverted(r_face_bleue, face_bleue, r_face_orange, face_orange, r_face_verte, face_verte, r_face_rouge, face_rouge, r_face_blanche, face_blanche);
                                green_on_right(r_face_jaune, face_jaune, r_face_bleue, face_bleue,  r_face_blanche, face_blanche, r_face_verte, face_verte, r_face_rouge,  face_rouge, r_face_orange, face_orange);}
                                
                        // vert à gauche
                        else if (face_bleue[0] == 'g'){
                                green_on_left(r_face_jaune, face_jaune, r_face_bleue, face_bleue,  r_face_blanche, face_blanche, r_face_verte, face_verte, r_face_rouge,  face_rouge, r_face_orange, face_orange);}
                                
                        else if(face_orange[0] == 'g'){
                                back(r_face_bleue,face_bleue, r_face_orange, face_orange,  r_face_verte, face_verte, r_face_rouge, face_rouge, r_face_blanche, face_blanche);
                                green_on_left(r_face_jaune, face_jaune, r_face_bleue, face_bleue,  r_face_blanche, face_blanche, r_face_verte, face_verte, r_face_rouge,  face_rouge, r_face_orange, face_orange);}
                                
                        else if(face_verte[0] == 'g'){
                                back(r_face_bleue,face_bleue, r_face_orange, face_orange,  r_face_verte, face_verte, r_face_rouge, face_rouge, r_face_blanche, face_blanche);
                                back(r_face_bleue,face_bleue, r_face_orange, face_orange,  r_face_verte, face_verte, r_face_rouge, face_rouge, r_face_blanche, face_blanche);
                                green_on_left(r_face_jaune, face_jaune, r_face_bleue, face_bleue,  r_face_blanche, face_blanche, r_face_verte, face_verte, r_face_rouge,  face_rouge, r_face_orange, face_orange);}
                                
                        else if(face_rouge[0] == 'g'){
                                back_inverted(r_face_bleue, face_bleue, r_face_orange, face_orange, r_face_verte, face_verte, r_face_rouge, face_rouge, r_face_blanche, face_blanche);
                                green_on_left(r_face_jaune, face_jaune, r_face_bleue, face_bleue,  r_face_blanche, face_blanche, r_face_verte, face_verte, r_face_rouge,  face_rouge, r_face_orange, face_orange);}
                }
        }
 
}
