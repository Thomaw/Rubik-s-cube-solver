/*
  movements.h - Bibliothèque permettant de définir l'ensemble 
  des mouvements réalisables par le Rubik's cube

  Créé par Dubouchet Thomas, 28 Novembre 2020
  Tout droit réservé
*/

/*
  Les procédures de cette bibliothèque seront en anglais car la terminologie utilisée
  est la terminologie officielle 

  
  Procédures de cette bibliothèque:
  
  void left 
     - Permets de réaliser le mouvement "L" sur Arduino
     
  void left_inverted
    - Permets de réaliser le mouvement "L'" sur Arduino

  void right
    - Permets de réaliser le mouvement "R" sur Arduino
    
  void right_inverted
    - Permets de réaliser le mouvement "R'" sur Arduino

  void down
    - Permets de réaliser le mouvement "D" sur Arduino
    
  void down_inverted
    - Permets de réaliser le mouvement "D'" sur Arduino

  void up
    - Permets de réaliser le mouvement "U" sur Arduino
    
  void up_inverted
    - Permets de réaliser le mouvement "U'" sur Arduino

  void back
    - Permets de réaliser le mouvement "B" sur Arduino
    
  void back_inverted
    - Permets de réaliser le mouvement "B'" sur Arduino

  void front
    - Permets de réaliser le mouvement "F" sur Arduino
    
  void front_inverted
    - Permets de réaliser le mouvement "F'" sur Arduino

  void flip_cube
    - Permets de retourner le cube sur Arduino selon un axe précis :
        - L'axe 'F', axe de la vue de face
        - L'axe 'U', axe de la vue du dessus
  
 */


// Les deux lignes ci-dessous permettent d'éviter les problèmes si quelqu'un inclut la bibliothèque deux fois.
#ifndef mouvements_h
#define mouvements_h


// ----------------------------------------------------------- //
// --------- Liste des procédures de la bibliothèque --------- //
// ----------------------------------------------------------- //

void left(char r_jaune[9], char jaune[9], char r_bleue[9], char bleue[9], char r_blanche[9], char blanche[9], char r_verte[9], char verte[9], char r_rouge[9], char rouge[9]);
void left_inverted(char r_jaune[9], char jaune[9], char r_bleue[9], char bleue[9],char r_blanche[9], char blanche[9], char r_verte[9], char verte[9], char r_rouge[9], char rouge[9]);

void right(char r_jaune[9], char jaune[9], char r_bleue[9], char bleue[9],char r_blanche[9], char blanche[9], char r_verte[9], char verte[9], char r_orange[9], char orange[9]);
void right_inverted(char r_jaune[9], char jaune[9], char r_bleue[9], char bleue[9],char r_blanche[9], char blanche[9], char r_verte[9], char verte[9], char r_orange[9], char orange[9]);

void down(char r_jaune[9], char jaune[9], char r_blanche[9], char blanche[9], char r_verte[9], char verte[9], char r_rouge[9], char rouge[9], char r_orange[9], char orange[9]);
void down_inverted(char r_jaune[9], char jaune[9], char r_blanche[9], char blanche[9], char r_verte[9], char verte[9], char r_rouge[9], char rouge[9], char r_orange[9], char orange[9]);

void up(char r_jaune[9], char jaune[9], char r_blanche[9], char blanche[9], char r_bleue[9], char bleue[9], char r_rouge[9], char rouge[9], char r_orange[9], char orange[9]);
void up_inverted(char r_jaune[9], char jaune[9], char r_blanche[9], char blanche[9], char r_bleue[9], char bleue[9], char r_rouge[9], char rouge[9], char r_orange[9], char orange[9]);

void back(char r_bleue[9], char bleue[9], char r_orange[9], char orange[9], char r_verte[9], char verte[9], char r_rouge[9], char rouge[9], char r_blanche[9], char blanche[9]);
void back_inverted(char r_bleue[9], char bleue[9], char r_orange[9], char orange[9], char r_verte[9], char verte[9], char r_rouge[9], char rouge[9], char r_blanche[9], char blanche[9]);

void front(char r_bleue[9], char bleue[9], char r_orange[9], char orange[9], char r_verte[9], char verte[9], char r_rouge[9], char rouge[9], char r_jaune[9], char jaune[9]);
void front_inverted(char r_bleue[9], char bleue[9], char r_orange[9], char orange[9], char r_verte[9], char verte[9], char r_rouge[9], char rouge[9], char r_jaune[9], char jaune[9]);

void flip_cube(char cube_rotation, char r_jaune[9], char jaune[9], char r_bleue[9], char bleue[9], char r_blanche[9], char blanche[9], char r_verte[9], char verte[9], char r_rouge[9], char rouge[9], char r_orange[9], char orange[9]);

#endif  // Fin de la création de la bibliothèque
