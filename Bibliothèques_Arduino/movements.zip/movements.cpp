#include <Arduino.h>   // Permets d'accéder aux types et constantes standard du language Arduino
#include "movements.h" // Permets d'accéder aux variables définies dans le Header

/// Mouvements possibles du cube ////

// Void left : - Initialise les cinq faces nécessaires pour fonctionner
//             - Initialise les cinq variables tampons permettant d'appliquer des modifications au cube
void left(char r_jaune[9], char jaune[9], char r_bleue[9], char bleue[9], char r_blanche[9], char blanche[9], char r_verte[9], char verte[9], char r_rouge[9], char rouge[9]) { // Initialise les cinq faces nécessaire pour fonctionner plus les 5 autres 
        Serial.print("L, ");      // Nom du mouvement simplifié

        // Simulation dans le cube
        for(int i = 0; i < 9; i++){     // Chaque valeur tampon prend sa face associée
          r_jaune[i] = jaune[i];
          r_bleue[i] = bleue[i];
          r_blanche[i] = blanche[i];
          r_verte[i] = verte[i];}

        for(int i = 0; i < 3; i++){    // Les pièces de cube sont alors remplacées par une nouvelle position 
          jaune[3*i] = r_bleue[3*i];
          bleue[3*i] = r_blanche[3*i];
          blanche[3*i] = r_verte[8-3*i];
          verte[8-3*i] = r_jaune[3*i];}
        
        for(int i = 0; i < 9; i++){r_rouge[i] = rouge[i];}
        for(int i = 0; i < 9; i++){rouge[i] = r_rouge[(36-3*i)%10];}}


// Void left_inverted : - Initialise les cinq faces nécessaires pour fonctionner
//                      - Initialise les cinq variables tampons permettant d'appliquer des modifications au cube
void left_inverted(char r_jaune[9], char jaune[9], char r_bleue[9], char bleue[9],char r_blanche[9], char blanche[9], char r_verte[9], char verte[9], char r_rouge[9], char rouge[9]){
        Serial.print("L', ");      // Nom du mouvement simplifié

        // Simulation dans le cube
        for(int i = 0; i < 9; i++){     // Chaque valeur tampon prend sa face associée
          r_jaune[i] = jaune[i];
          r_bleue[i] = bleue[i];
          r_blanche[i] = blanche[i];
          r_verte[i] = verte[i];}

        for(int i = 0; i < 3; i++){    // Les pièces de cube sont alors remplacées par une nouvelle position 
          bleue[3*i] = r_jaune[3*i];
          blanche[3*i] = r_bleue[3*i];
          jaune[3*i] = r_verte[8-3*i];
          verte[8-3*i] = r_blanche[3*i];}
        
        for(int i = 0; i < 9; i++){r_rouge[i] = rouge[i];}
        for(int i = 0; i < 9; i++){rouge[i] = r_rouge[(3*i+2)%10];}}


// Void right : - Initialise les cinq faces nécessaires pour fonctionner
//              - Initialise les cinq variables tampons permettant d'appliquer des modifications au cube
void right(char r_jaune[9], char jaune[9], char r_bleue[9], char bleue[9],char r_blanche[9], char blanche[9], char r_verte[9], char verte[9], char r_orange[9], char orange[9]){
        Serial.print("R, ");      // Nom du mouvement simplifié

        // Simulation dans le cube
        for(int i = 0; i < 9; i++){     // Chaque valeur tampon prend sa face associée
          r_jaune[i] = jaune[i];
          r_bleue[i] = bleue[i];
          r_blanche[i] = blanche[i];
          r_verte[i] = verte[i];}
        
        for(int i = 0; i < 3; i++){     // Les pièces de cube sont alors remplacées par une nouvelle position 
          verte[3*i] = r_blanche[8-3*i];
          bleue[3*i+2] = r_jaune[3*i+2];
          blanche[3*i+2] = r_bleue[3*i+2];
          jaune[8-3*i] = r_verte[3*i];}
 
        for(int i = 0; i < 9; i++){r_orange[i] = orange[i];}
        for(int i = 0; i < 9; i++){orange[i] = r_orange[(36-3*i)%10];}}


// Void right_inverted : - Initialise les cinq faces nécessaires pour fonctionner
//                      - Initialise les cinq variables tampons permettant d'appliquer des modifications au cube
void right_inverted(char r_jaune[9], char jaune[9], char r_bleue[9], char bleue[9],char r_blanche[9], char blanche[9], char r_verte[9], char verte[9], char r_orange[9], char orange[9]){
        Serial.print("R', ");      // Nom du mouvement simplifié
 
        // Simulation dans le cube
        for(int i = 0; i < 9; i++){     // Chaque valeur tampon prend sa face associée
          r_jaune[i] = jaune[i];
          r_bleue[i] = bleue[i];
          r_blanche[i] = blanche[i];
          r_verte[i] = verte[i];}

        for(int i = 0; i < 3; i++){     // Les pièces de cube sont alors remplacées par une nouvelle position 
          jaune[3*i+2] = r_bleue[3*i+2];
          bleue[3*i+2] = r_blanche[3*i+2];
          blanche[8-3*i] = r_verte[3*i];
          verte[3*i] = r_jaune[8-3*i];}

 
        for(int i = 0; i < 9; i++){r_orange[i] = orange[i];}
        for(int i = 0; i < 9; i++){orange[i] = r_orange[(3*i+2)%10];}}


// Void down : - Initialise les cinq faces nécessaires pour fonctionner
//             - Initialise les cinq variables tampons permettant d'appliquer des modifications au cube
void down(char r_jaune[9], char jaune[9], char r_blanche[9], char blanche[9], char r_verte[9], char verte[9], char r_rouge[9], char rouge[9], char r_orange[9], char orange[9]){
        Serial.print("D, ");      // Nom du mouvement simplifié

        // Simulation dans le cube
        for(int i = 0; i < 9; i++){     // Chaque valeur tampon prend sa face associée
          r_jaune[i] = jaune[i];
          r_orange[i] = orange[i];
          r_blanche[i] = blanche[i];
          r_rouge[i] = rouge[i];}

        for(int i = 0; i < 3; i++){     // Les pièces de cube sont alors remplacées par une nouvelle position 
          orange[8-3*i] = r_jaune[6+i];
          jaune[6+i] = r_rouge[3*i];
          rouge[3*i] = r_blanche[2-i];
          blanche[i] = r_orange[3*i+2];}
        
        for(int i = 0; i < 9; i++){ r_verte[i] = verte[i];}
        for(int i = 0; i < 9; i++){verte[i] = r_verte[(36-3*i)%10];}}


// Void down_inverted : - Initialise les cinq faces nécessaires pour fonctionner
//                      - Initialise les cinq variables tampons permettant d'appliquer des modifications au cube
void down_inverted(char r_jaune[9], char jaune[9], char r_blanche[9], char blanche[9], char r_verte[9], char verte[9], char r_rouge[9], char rouge[9], char r_orange[9], char orange[9]){
        Serial.print("D', ");      // Nom du mouvement simplifié

        // Simulation dans le cube
        for(int i = 0; i < 9; i++){     // Chaque valeur tampon prend sa face associée
          r_jaune[i] = jaune[i];
          r_orange[i] = orange[i];
          r_blanche[i] = blanche[i];
          r_rouge[i] = rouge[i];}

        for(int i = 0; i < 3; i++){     // Les pièces de cube sont alors remplacées par une nouvelle position 
          jaune[6+i] = r_orange[8-3*i];
          rouge[3*i] = r_jaune[6+i];
          blanche[i] = r_rouge[6-3*i];
          orange[3*i+2] = r_blanche[i];}
 
        for(int i = 0; i < 9; i++){r_verte[i] = verte[i];}
        for(int i = 0; i < 9; i++){verte[i] = r_verte[(3*i+2)%10];}}


// Void up : - Initialise les cinq faces nécessaires pour fonctionner
//           - Initialise les cinq variables tampons permettant d'appliquer des modifications au cube
void up(char r_jaune[9], char jaune[9], char r_blanche[9], char blanche[9], char r_bleue[9], char bleue[9], char r_rouge[9], char rouge[9], char r_orange[9], char orange[9]){
        Serial.print("U, ");      // Nom du mouvement simplifié
 
        // Simulation dans le cube
        for(int i = 0; i < 9; i++){     // Chaque valeur tampon prend sa face associée
                r_jaune[i] = jaune[i];
                r_orange[i] = orange[i];
                r_blanche[i] = blanche[i];
                r_rouge[i] = rouge[i];}

        for(int i = 0; i < 3; i++){     // Les pièces de cube sont alors remplacées par une nouvelle position 
          jaune[i] = r_orange[6-3*i];
          rouge[3*i+2] = r_jaune[i];
          blanche[6+i] = r_rouge[8-3*i];
          orange[3*i] = r_blanche[6+i];}
 
        for(int i = 0; i < 9; i++){r_bleue[i] = bleue[i];}
        for(int i = 0; i < 9; i++){bleue[i] = r_bleue[(36-3*i)%10];}}

// Void up_inverted : - Initialise les cinq faces nécessaires pour fonctionner
//                    - Initialise les cinq variables tampons permettant d'appliquer des modifications au cube
void up_inverted(char r_jaune[9], char jaune[9], char r_blanche[9], char blanche[9], char r_bleue[9], char bleue[9], char r_rouge[9], char rouge[9], char r_orange[9], char orange[9]){
        Serial.print("U', ");      // Nom du mouvement simplifié
        
        // Simulation dans le cube
        for(int i = 0; i < 9; i++){     // Chaque valeur tampon prend sa face associée
          r_jaune[i] = jaune[i];
          r_orange[i] = orange[i];
          r_blanche[i] = blanche[i];
          r_rouge[i] = rouge[i];}

        for(int i = 0; i < 3; i++){     // Les pièces de cube sont alors remplacées par une nouvelle position 
          orange[6-3*i] = r_jaune[i];
          jaune[i] = r_rouge[3*i+2];
          rouge[3*i+2] = r_blanche[8-i];
          blanche[6+i] = r_orange[3*i];}
 
        for(int i = 0; i < 9; i++){r_bleue[i] = bleue[i];}
        for(int i = 0; i < 9; i++){bleue[i] = r_bleue[(3*i+2)%10];}}


// Void back : - Initialise les cinq faces nécessaires pour fonctionner
//             - Initialise les cinq variables tampons permettant d'appliquer des modifications au cube
void back(char r_bleue[9], char bleue[9], char r_orange[9], char orange[9], char r_verte[9], char verte[9], char r_rouge[9], char rouge[9], char r_blanche[9], char blanche[9]){
        Serial.print("B, ");      // Nom du mouvement simplifié
 
        // Simulation dans le cube
        for(int i = 0; i < 9; i++){     // Chaque valeur tampon prend sa face associée
          r_bleue[i] = bleue[i];
          r_orange[i] = orange[i];
          r_verte[i] = verte[i];
          r_rouge[i] = rouge[i];}

        for(int i = 0; i < 3; i++){     // Les pièces de cube sont alors remplacées par une nouvelle position 
          bleue[i] = r_orange[i];
          rouge[i] = r_bleue[i];
          verte[i] = r_rouge[i];
          orange[i] = r_verte[i];}

        for(int i = 0; i < 9; i++){r_blanche[i] = blanche[i];}
        for(int i = 0; i < 9; i++){blanche[i] = r_blanche[(36-3*i)%10];}}


// Void back_inverted : - Initialise les cinq faces nécessaires pour fonctionner
//                      - Initialise les cinq variables tampons permettant d'appliquer des modifications au cube
void back_inverted(char r_bleue[9], char bleue[9], char r_orange[9], char orange[9], char r_verte[9], char verte[9], char r_rouge[9], char rouge[9], char r_blanche[9], char blanche[9]){
        Serial.print("B', ");
 
        // Simulation dans le cube
        for(int i = 0; i < 9; i++){     // Chaque valeur tampon prend sa face associée
          r_bleue[i] = bleue[i];
          r_orange[i] = orange[i];
          r_verte[i] = verte[i];
          r_rouge[i] = rouge[i];}

        for(int i = 0; i < 3; i++){     // Les pièces de cube sont alors remplacées par une nouvelle position 
          bleue[i] = r_rouge[i];
          rouge[i] = r_verte[i];
          verte[i] = r_orange[i];
          orange[i] = r_bleue[i];}
 
        for(int i = 0; i < 9; i++){r_blanche[i] = blanche[i];}
        for(int i = 0; i < 9; i++){blanche[i] = r_blanche[(3*i+2)%10];}}


// Void front : - Initialise les cinq faces nécessaires pour fonctionner
//              - Initialise les cinq variables tampons permettant d'appliquer des modifications au cube
void front(char r_bleue[9], char bleue[9], char r_orange[9], char orange[9], char r_verte[9], char verte[9], char r_rouge[9], char rouge[9], char r_jaune[9], char jaune[9]){
        Serial.print("F, ");

        // Simulation dans le cube
        for(int i = 0; i < 9; i++){     // Chaque valeur tampon prend sa face associée
          r_bleue[i] = bleue[i];
          r_orange[i] = orange[i];
          r_verte[i] = verte[i];
          r_rouge[i] = rouge[i];}

        for(int i = 0; i < 3; i++){     // Les pièces de cube sont alors remplacées par une nouvelle position 
          bleue[6+i] = r_rouge[6+i];
          rouge[6+i] = r_verte[6+i];
          verte[6+i] = r_orange[6+i];
          orange[6+i] = r_bleue[6+i];}
        
        for(int i = 0; i < 9; i++){r_jaune[i] = jaune[i];}
        for(int i = 0; i < 9; i++){jaune[i] = r_jaune[(36-3*i)%10];}}


// Void front_inverted : - Initialise les cinq faces nécessaires pour fonctionner
//                       - Initialise les cinq variables tampons permettant d'appliquer des modifications au cube
void front_inverted(char r_bleue[9], char bleue[9], char r_orange[9], char orange[9], char r_verte[9], char verte[9], char r_rouge[9], char rouge[9], char r_jaune[9], char jaune[9]){
        Serial.print("F', ");
 
        // Simulation dans le cube
        for(int i = 0; i < 9; i++){     // Chaque valeur tampon prend sa face associée
          r_bleue[i] = bleue[i];
          r_orange[i] = orange[i];
          r_verte[i] = verte[i];
          r_rouge[i] = rouge[i];}

        for(int i = 0; i < 3; i++){     // Les pièces de cube sont alors remplacées par une nouvelle position 
          bleue[6+i] = r_orange[6+i];
          rouge[6+i] = r_bleue[6+i];
          verte[6+i] = r_rouge[6+i];
          orange[6+i] = r_verte[6+i];}
 
        for(int i = 0; i < 9; i++){r_jaune[i] = jaune[i];}
        for(int i = 0; i < 9; i++){jaune[i] = r_jaune[(3*i+2)%10];}}



// Void flip_cube : - Initialise les six faces nécessaires pour fonctionner
//                  - Initialise les six variables tampons permettant d'appliquer des modifications au cube
//                  - Initialise le nom de l'axe de rotation 'F' ou 'U'
void flip_cube(char cube_rotation, char r_jaune[9], char jaune[9], char r_bleue[9], char bleue[9], char r_blanche[9], char blanche[9], char r_verte[9], char verte[9], char r_rouge[9], char rouge[9], char r_orange[9], char orange[9]){      // Tourne le cube sur l'axe 'F' ou 'U'
        
        // Simulation dans le cube
        for(int i = 0; i < 9; i++){     // Chaque valeur tampon prend sa face associée
          r_bleue[i] = bleue[i];
          r_orange[i] = orange[i];
          r_verte[i] = verte[i];
          r_rouge[i] = rouge[i];}
          
        for(int i = 0; i < 9; i++){
          r_blanche[i] = blanche[i];
          r_jaune[i] = jaune[i];}
          
        switch(cube_rotation){
                case 'F': // CW sur F
                        Serial.print("[Cube Flip: CW on F], ");

                        // Simulation dans le cube
                        for(int i = 0; i < 9; i++){
                          orange[i] = r_bleue[i];
                          verte[i] = r_orange[i];
                          rouge[i] = r_verte[i];
                          bleue[i] = r_rouge[i];}

                        for(int i = 0; i < 9; i++){blanche[i] = r_blanche[(3*i+2)%10];}
                        for(int i = 0; i < 9; i++){jaune[i] = r_jaune[(36-3*i)%10];}
                        break;
                        
                case 'f': // CCW sur f
                        Serial.print("[Cube Flip: CCW on F], ");

                        // Simulation dans le cube
                        for(int i = 0; i < 9; i++){
                          rouge[i] = r_bleue[i];
                          bleue[i] = r_orange[i];
                          orange[i] = r_verte[i];
                          verte[i] = r_rouge[i];}

                        for(int i = 0; i < 9; i++){jaune[i] = r_jaune[(3*i+2)%10];}
                        for(int i = 0; i < 9; i++){blanche[i] = r_blanche[(36-3*i)%10];}
                        break;
                
                default:
                        Serial.println("INVALID CUBE ROTATION: SEE < void flip_cube() >");
        }
}