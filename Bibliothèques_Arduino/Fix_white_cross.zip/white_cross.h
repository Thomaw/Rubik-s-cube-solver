/*
  white_cross.h - Bibliothèque permettant de résoudre
  la croix opposée à la face jaune

  Créé par Dubouchet Thomas, 29 Décembre 2020
  Tout droit réservé
*/

/*
  Les procédures de cette bibliothèque seront en anglais car la terminologie utilisée
  est la terminologie officielle 

  
  Procédures de cette bibliothèque:

  void white_cross_on_top
    - Permets de réaliser la suite de mouvements suivante:
      R', B', U', B, U, R
    
  void finish_white_face_instance_1
    - Permets de réaliser la suite de mouvements suivante:
      R, B, R', B, R, B, B, R'

  void finish_white_face_instance_2
    - Permets de réaliser la suite de mouvements suivante:
      L', B', L, B', L', B', B', L

 */

// Les deux lignes ci-dessous permettent d'éviter les problèmes si quelqu'un inclut la bibliothèque deux fois.
#ifndef white_cross_h
#define white_cross_h

// ----------------------------------------------------------- //
// --------- Liste des procédures de la bibliothèque --------- //
// ----------------------------------------------------------- //

void white_cross_on_top(char r_face_jaune[9], char face_jaune[9], char r_face_bleue[9], char face_bleue[9], char r_face_blanche[9], char face_blanche[9], char r_face_verte[9], char face_verte[9], char r_face_rouge[9], char face_rouge[9], char r_face_orange[9], char face_orange[9]);
void finish_white_face_instance_1(char r_face_jaune[9], char face_jaune[9], char r_face_bleue[9], char face_bleue[9], char r_face_blanche[9], char face_blanche[9], char r_face_verte[9], char face_verte[9], char r_face_rouge[9], char face_rouge[9], char r_face_orange[9], char face_orange[9]);
void finish_white_face_instance_2(char r_face_jaune[9], char face_jaune[9], char r_face_bleue[9], char face_bleue[9], char r_face_blanche[9], char face_blanche[9], char r_face_verte[9], char face_verte[9], char r_face_rouge[9], char face_rouge[9], char r_face_orange[9], char face_orange[9]);

#endif  // Fin de la création de la bibliothèque
