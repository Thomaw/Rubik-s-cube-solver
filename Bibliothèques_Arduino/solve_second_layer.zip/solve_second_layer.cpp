#include <Arduino.h>             // Permet d'accéder aux types et constantes standard du language Arduino 
#include "movements.h"           // Permet d'accéder aux fonctions définies dans la bibliothèques "movements.h"
#include "rotation.h"            // Permet d'accéder aux fonctions définies dans la bibliothèques "rotation.h"
#include "fix_cross.h"           // Permet d'accéder aux fonctions définies dans la bibliothèques "fix_cross.h"
#include "fix_corners.h"         // Permet d'accéder aux fonctions définies dans la bibliothèques "fix_corners.h"
#include "fix_last_corners.h"    // Permet d'accéder aux fonctions définies dans la bibliothèques "fix_last_corners.h"
#include "affichage_cube.h"      // Permet d'accéder aux fonctions définies dans la bibliothèques "affichage_cube.h"
#include "edges.h"               // Permet d'accéder aux fonctions définies dans la bibliothèques "edges.h"
#include "white_cross.h"         // Permet d'accéder aux fonctions définies dans la bibliothèques "white_cross.h"
#include "solve_corners.h"       // Permet d'accéder aux variables définies dans le Header


// Création variable statique 
static int my_former_global;

// Fonction qui renvoie la varible statique
int get_global_4() {
  return my_former_global;
  }

void set_global_4(int solve_stage) {
  if (solve_stage == 5 && my_former_global != 5) {my_former_global = 5;}  // Si la croix a été réalisée, on passe à l'étape suivante
  }

void cube_decide_add_edges(int solve_stage, char r_face_jaune[9], char face_jaune[9], char r_face_bleue[9], char face_bleue[9], char r_face_blanche[9], char face_blanche[9], char r_face_verte[9], char face_verte[9], char r_face_rouge[9], char face_rouge[9], char r_face_orange[9], char face_orange[9]) {
        
        Serial.println();
        Serial.println();
        Serial.print("Edges (Second Layer): ");
        ///// Deuxième courpnne réalisée
        if (solve_stage == 4 && face_verte[3] == 'g' && face_verte[5] == 'g' && face_rouge[3] == 'r' && face_rouge[5] == 'r' &&
            face_bleue[3] == 'b' && face_bleue[5] == 'b' && face_orange[3] == 'o' && face_orange[5] == 'o'){
                Serial.print("Solved.");
                solve_stage = 5;
                set_global_4(solve_stage);} // Renvoie la variable solve_stage
                
        else if(solve_stage == 4){
                ///// 3 rouge --> 2 bleu
                if(face_rouge[1] == 'r' && face_blanche[3] == 'b'){
                        flip_cube( 'F',  r_face_jaune,  face_jaune,  r_face_bleue, face_bleue,  r_face_blanche,  face_blanche,  r_face_verte,  face_verte,  r_face_rouge, face_rouge,  r_face_orange,  face_orange);
                        add_edges_instance_2( r_face_jaune, face_jaune, r_face_bleue, face_bleue,  r_face_blanche, face_blanche, r_face_verte, face_verte, r_face_rouge,  face_rouge, r_face_orange, face_orange); // two right
                        flip_cube( 'f',  r_face_jaune,  face_jaune,  r_face_bleue, face_bleue,  r_face_blanche,  face_blanche,  r_face_verte,  face_verte,  r_face_rouge, face_rouge,  r_face_orange,  face_orange);}
                        
                ///// 2 rouge --> 3 bleu
                else if(face_bleue[1] == 'b' && face_blanche[7] == 'r'){
                  add_edges_instance_1( r_face_jaune, face_jaune, r_face_bleue, face_bleue,  r_face_blanche, face_blanche, r_face_verte, face_verte, r_face_rouge,  face_rouge, r_face_orange, face_orange);} // two left
 
                //// 3 bleu --> orange
                else if(face_bleue[1] == 'b' && face_blanche[7] == 'o'){
                        add_edges_instance_2( r_face_jaune, face_jaune, r_face_bleue, face_bleue,  r_face_blanche, face_blanche, r_face_verte, face_verte, r_face_rouge,  face_rouge, r_face_orange, face_orange);} // two right
                
                //// bleu --> 3 orange
                else if(face_orange[1] == 'o' && face_blanche[5] == 'b'){
                        flip_cube( 'f',  r_face_jaune,  face_jaune,  r_face_bleue, face_bleue,  r_face_blanche,  face_blanche,  r_face_verte,  face_verte,  r_face_rouge, face_rouge,  r_face_orange,  face_orange);
                        add_edges_instance_1( r_face_jaune, face_jaune, r_face_bleue, face_bleue,  r_face_blanche, face_blanche, r_face_verte, face_verte, r_face_rouge,  face_rouge, r_face_orange, face_orange); // two left
                        flip_cube( 'F',  r_face_jaune,  face_jaune,  r_face_bleue, face_bleue,  r_face_blanche,  face_blanche,  r_face_verte,  face_verte,  r_face_rouge, face_rouge,  r_face_orange,  face_orange);}
                        
                //// 3 orange --> vert
                else if(face_orange[1] == 'o' && face_blanche[5] == 'g'){
                        flip_cube( 'f',  r_face_jaune,  face_jaune,  r_face_bleue, face_bleue,  r_face_blanche,  face_blanche,  r_face_verte,  face_verte,  r_face_rouge, face_rouge,  r_face_orange,  face_orange);
                        add_edges_instance_2( r_face_jaune, face_jaune, r_face_bleue, face_bleue,  r_face_blanche, face_blanche, r_face_verte, face_verte, r_face_rouge,  face_rouge, r_face_orange, face_orange); // two right
                        flip_cube( 'F',  r_face_jaune,  face_jaune,  r_face_bleue, face_bleue,  r_face_blanche,  face_blanche,  r_face_verte,  face_verte,  r_face_rouge, face_rouge,  r_face_orange,  face_orange);}
                        
                //// orange --> 3 vert
                else if(face_verte[1] == 'g' && face_blanche[1] == 'o'){
                        flip_cube( 'F',  r_face_jaune,  face_jaune,  r_face_bleue, face_bleue,  r_face_blanche,  face_blanche,  r_face_verte,  face_verte,  r_face_rouge, face_rouge,  r_face_orange,  face_orange);
                        flip_cube( 'F',  r_face_jaune,  face_jaune,  r_face_bleue, face_bleue,  r_face_blanche,  face_blanche,  r_face_verte,  face_verte,  r_face_rouge, face_rouge,  r_face_orange,  face_orange);
                        add_edges_instance_1( r_face_jaune, face_jaune, r_face_bleue, face_bleue,  r_face_blanche, face_blanche, r_face_verte, face_verte, r_face_rouge,  face_rouge, r_face_orange, face_orange); // two left
                        flip_cube( 'f',  r_face_jaune,  face_jaune,  r_face_bleue, face_bleue,  r_face_blanche,  face_blanche,  r_face_verte,  face_verte,  r_face_rouge, face_rouge,  r_face_orange,  face_orange);
                        flip_cube( 'f',  r_face_jaune,  face_jaune,  r_face_bleue, face_bleue,  r_face_blanche,  face_blanche,  r_face_verte,  face_verte,  r_face_rouge, face_rouge,  r_face_orange,  face_orange);}
 
                //// 3 vert --> rouge
                else if(face_verte[1] == 'g' && face_blanche[1] == 'r'){
                        flip_cube( 'F',  r_face_jaune,  face_jaune,  r_face_bleue, face_bleue,  r_face_blanche,  face_blanche,  r_face_verte,  face_verte,  r_face_rouge, face_rouge,  r_face_orange,  face_orange);
                        flip_cube( 'F',  r_face_jaune,  face_jaune,  r_face_bleue, face_bleue,  r_face_blanche,  face_blanche,  r_face_verte,  face_verte,  r_face_rouge, face_rouge,  r_face_orange,  face_orange);
                        add_edges_instance_2( r_face_jaune, face_jaune, r_face_bleue, face_bleue,  r_face_blanche, face_blanche, r_face_verte, face_verte, r_face_rouge,  face_rouge, r_face_orange, face_orange); // two right
                        flip_cube( 'f',  r_face_jaune,  face_jaune,  r_face_bleue, face_bleue,  r_face_blanche,  face_blanche,  r_face_verte,  face_verte,  r_face_rouge, face_rouge,  r_face_orange,  face_orange);
                        flip_cube( 'f',  r_face_jaune,  face_jaune,  r_face_bleue, face_bleue,  r_face_blanche,  face_blanche,  r_face_verte,  face_verte,  r_face_rouge, face_rouge,  r_face_orange,  face_orange);}
                        
                //// vert --> 3 rouge
                else if(face_rouge[1] == 'r' && face_blanche[3] == 'g'){
                        flip_cube( 'F',  r_face_jaune,  face_jaune,  r_face_bleue, face_bleue,  r_face_blanche,  face_blanche,  r_face_verte,  face_verte,  r_face_rouge, face_rouge,  r_face_orange,  face_orange);
                        add_edges_instance_1( r_face_jaune, face_jaune, r_face_bleue, face_bleue,  r_face_blanche, face_blanche, r_face_verte, face_verte, r_face_rouge,  face_rouge, r_face_orange, face_orange); // two left
                        flip_cube( 'f',  r_face_jaune,  face_jaune,  r_face_bleue, face_bleue,  r_face_blanche,  face_blanche,  r_face_verte,  face_verte,  r_face_rouge, face_rouge,  r_face_orange,  face_orange);}
                        
                //// faire pivoter la couche supérieure pour faire correspondre les couleurs manquantes
                else if (face_bleue[3] == 'w' || face_bleue[5] == 'w' || face_rouge[3] == 'w' || face_rouge[5] == 'w' ||
                        face_verte[3] == 'w' || face_verte[5] == 'w' || face_orange[3] == 'w' || face_orange[5] == 'w'){
                        back(r_face_bleue,face_bleue, r_face_orange, face_orange,  r_face_verte, face_verte, r_face_rouge, face_rouge, r_face_blanche, face_blanche);}
 
                ///// remettre les bords mal placés au sommet
                else if (face_bleue[3] != 'b' || face_rouge[5] != 'r' || face_rouge[3] != 'r' || face_verte[5] != 'g' ||
                         face_verte[3] != 'g' || face_orange[5] != 'o' || face_orange[3] != 'o' || face_bleue[5] != 'b'){
                        if(face_bleue[3] != 'b' || face_rouge[5] != 'r'){
                                flip_cube( 'F',  r_face_jaune,  face_jaune,  r_face_bleue, face_bleue,  r_face_blanche,  face_blanche,  r_face_verte,  face_verte,  r_face_rouge, face_rouge,  r_face_orange,  face_orange);
                                add_edges_instance_3( r_face_jaune, face_jaune, r_face_bleue, face_bleue,  r_face_blanche, face_blanche, r_face_verte, face_verte, r_face_rouge,  face_rouge, r_face_orange, face_orange);
                                flip_cube( 'f',  r_face_jaune,  face_jaune,  r_face_bleue, face_bleue,  r_face_blanche,  face_blanche,  r_face_verte,  face_verte,  r_face_rouge, face_rouge,  r_face_orange,  face_orange);}
                                
                        else if(face_rouge[3] != 'r' || face_verte[5] != 'g'){
                                flip_cube( 'F',  r_face_jaune,  face_jaune,  r_face_bleue, face_bleue,  r_face_blanche,  face_blanche,  r_face_verte,  face_verte,  r_face_rouge, face_rouge,  r_face_orange,  face_orange);
                                flip_cube( 'F',  r_face_jaune,  face_jaune,  r_face_bleue, face_bleue,  r_face_blanche,  face_blanche,  r_face_verte,  face_verte,  r_face_rouge, face_rouge,  r_face_orange,  face_orange);
                                add_edges_instance_3( r_face_jaune, face_jaune, r_face_bleue, face_bleue,  r_face_blanche, face_blanche, r_face_verte, face_verte, r_face_rouge,  face_rouge, r_face_orange, face_orange);
                                flip_cube( 'f',  r_face_jaune,  face_jaune,  r_face_bleue, face_bleue,  r_face_blanche,  face_blanche,  r_face_verte,  face_verte,  r_face_rouge, face_rouge,  r_face_orange,  face_orange);
                                flip_cube( 'f',  r_face_jaune,  face_jaune,  r_face_bleue, face_bleue,  r_face_blanche,  face_blanche,  r_face_verte,  face_verte,  r_face_rouge, face_rouge,  r_face_orange,  face_orange);}
                                
                        else if(face_verte[3] != 'g' || face_orange[5] != 'o'){
                                flip_cube( 'f',  r_face_jaune,  face_jaune,  r_face_bleue, face_bleue,  r_face_blanche,  face_blanche,  r_face_verte,  face_verte,  r_face_rouge, face_rouge,  r_face_orange,  face_orange);
                                add_edges_instance_3( r_face_jaune, face_jaune, r_face_bleue, face_bleue,  r_face_blanche, face_blanche, r_face_verte, face_verte, r_face_rouge,  face_rouge, r_face_orange, face_orange);
                                flip_cube( 'F',  r_face_jaune,  face_jaune,  r_face_bleue, face_bleue,  r_face_blanche,  face_blanche,  r_face_verte,  face_verte,  r_face_rouge, face_rouge,  r_face_orange,  face_orange);}
                                
                        else if(face_orange[3] != 'o' || face_bleue[5] != 'b'){
                                add_edges_instance_3( r_face_jaune, face_jaune, r_face_bleue, face_bleue,  r_face_blanche, face_blanche, r_face_verte, face_verte, r_face_rouge,  face_rouge, r_face_orange, face_orange);}
                }
                else{Serial.println("second layer not solved.");} // Erreur 
        }
}
