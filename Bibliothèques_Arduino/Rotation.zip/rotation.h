/*
  Rotation.h - Bibliothèque permettant de tourner le 
  cube dans le sens horaire et anti-horaire

  Créé par Dubouchet Thomas, 29 Décembre 2020
  Tout droit réservé
*/

/*
  Les procédures de cette bibliothèque seront en anglais car la terminologie utilisée
  est la terminologie officielle 

  
  Procédures de cette bibliothèque:
  
  void cw_rotation
    - Permets de tourner le cube dans le sens horaire

  void ccw_rotation
    - Permets de tourner le cube dans le sens anti-horaire
 */
 

// Les deux lignes ci-dessous permettent d'éviter les problèmes si quelqu'un inclut la bibliothèque deux fois.
#ifndef rotation_h
#define rotation_h

// ----------------------------------------------------------- //
// --------- Liste des procédures de la bibliothèque --------- //
// ----------------------------------------------------------- //

void cw_rotation(char r_face_jaune[9], char face_jaune[9], char r_face_bleue[9], char face_bleue[9], char r_face_blanche[9], char face_blanche[9], char r_face_verte[9], char face_verte[9], char r_face_rouge[9], char face_rouge[9], char r_face_orange[9], char face_orange[9]); // can also be used for 4 bad edges
void ccw_rotation(char r_face_jaune[9], char face_jaune[9], char r_face_bleue[9], char face_bleue[9], char r_face_blanche[9], char face_blanche[9], char r_face_verte[9], char face_verte[9], char r_face_rouge[9], char face_rouge[9], char r_face_orange[9], char face_orange[9]);

#endif  // Fin de la création de la bibliothèque

