#include <Arduino.h>     // Permet d'accéder aux types et constantes standard du language Arduino
#include "white_cross.h" // Permet d'accéder aux fonctions définies dans la bibliothèques "white_cross.h"
#include "movements.h"   // Permet d'accéder aux fonctions définies dans la bibliothèques "movements.h"
#include "rotation.h"    // Permet d'accéder aux variables définies dans le Header

// Tourne le cube dans le sens horaire
void cw_rotation(char r_face_jaune[9], char face_jaune[9], char r_face_bleue[9], char face_bleue[9], char r_face_blanche[9], char face_blanche[9], char r_face_verte[9], char face_verte[9], char r_face_rouge[9], char face_rouge[9], char r_face_orange[9], char face_orange[9]){ // can also be used for 4 bad edges{
        Serial.println();
        Serial.print("  CW Rotation: ");
        finish_white_face_instance_1(r_face_jaune, face_jaune, r_face_bleue, face_bleue,  r_face_blanche, face_blanche, r_face_verte, face_verte, r_face_rouge,  face_rouge, r_face_orange, face_orange);
        flip_cube( 'f',  r_face_jaune,  face_jaune,  r_face_bleue, face_bleue,  r_face_blanche,  face_blanche,  r_face_verte,  face_verte,  r_face_rouge, face_rouge,  r_face_orange,  face_orange);// rotate cube: right side = front side
        finish_white_face_instance_2(r_face_jaune, face_jaune, r_face_bleue, face_bleue,  r_face_blanche, face_blanche, r_face_verte, face_verte, r_face_rouge,  face_rouge, r_face_orange, face_orange);
        flip_cube( 'F',  r_face_jaune,  face_jaune,  r_face_bleue, face_bleue,  r_face_blanche,  face_blanche,  r_face_verte,  face_verte,  r_face_rouge, face_rouge,  r_face_orange,  face_orange);}// rotate cube back to original state: left side = front side


// Tourne le cube dans le sens anti-horaire
void ccw_rotation(char r_face_jaune[9], char face_jaune[9], char r_face_bleue[9], char face_bleue[9], char r_face_blanche[9], char face_blanche[9], char r_face_verte[9], char face_verte[9], char r_face_rouge[9], char face_rouge[9], char r_face_orange[9], char face_orange[9]){
        Serial.println();
        Serial.print("  CCW Rotation: ");
        finish_white_face_instance_2(r_face_jaune, face_jaune, r_face_bleue, face_bleue,  r_face_blanche, face_blanche, r_face_verte, face_verte, r_face_rouge,  face_rouge, r_face_orange, face_orange);
        flip_cube( 'F',  r_face_jaune,  face_jaune,  r_face_bleue, face_bleue,  r_face_blanche,  face_blanche,  r_face_verte,  face_verte,  r_face_rouge, face_rouge,  r_face_orange,  face_orange);// rotate cube: left side = front side
        finish_white_face_instance_1(r_face_jaune, face_jaune, r_face_bleue, face_bleue,  r_face_blanche, face_blanche, r_face_verte, face_verte, r_face_rouge,  face_rouge, r_face_orange, face_orange);
        flip_cube( 'f',  r_face_jaune,  face_jaune,  r_face_bleue, face_bleue,  r_face_blanche,  face_blanche,  r_face_verte,  face_verte,  r_face_rouge, face_rouge,  r_face_orange,  face_orange);}