/*
  edges.h - Bibliothèque permettant de positionner
  correctement les angles de la deuxième couronne
 

  Créé par Dubouchet Thomas, 29 Décembre 2020
  Tout droit réservé
*/

/*
  Les procédures de cette bibliothèque seront en anglais car la terminologie utilisée
  est la terminologie officielle 

  
  Procédures de cette bibliothèque:
  
  void add_edges_instance_1
    - Permets de réaliser la suite de mouvements suivante:
    B', L', B, L, B, U, B', U'

  void add_edges_instance_2
    - Permets de réaliser la suite de mouvements suivante:
    B, R, B', R', B', U', B, U

  void add_edges_instance_3
    - Permets de réaliser la suite de mouvements suivante:
    B', U', B, U, B, R, B', R'
 */
 

// Les deux lignes ci-dessous permettent d'éviter les problèmes si quelqu'un inclut la bibliothèque deux fois.
#ifndef edges_h
#define edges_h

// ----------------------------------------------------------- //
// --------- Liste des procédures de la bibliothèque --------- //
// ----------------------------------------------------------- //

void add_edges_instance_1(char r_face_jaune[9], char face_jaune[9], char r_face_bleue[9], char face_bleue[9], char r_face_blanche[9], char face_blanche[9], char r_face_verte[9], char face_verte[9], char r_face_rouge[9], char face_rouge[9], char r_face_orange[9], char face_orange[9]);
void add_edges_instance_2(char r_face_jaune[9], char face_jaune[9], char r_face_bleue[9], char face_bleue[9], char r_face_blanche[9], char face_blanche[9], char r_face_verte[9], char face_verte[9], char r_face_rouge[9], char face_rouge[9], char r_face_orange[9], char face_orange[9]);
void add_edges_instance_3(char r_face_jaune[9], char face_jaune[9], char r_face_bleue[9], char face_bleue[9], char r_face_blanche[9], char face_blanche[9], char r_face_verte[9], char face_verte[9], char r_face_rouge[9], char face_rouge[9], char r_face_orange[9], char face_orange[9]);

#endif  // Fin de la création de la bibliothèque
